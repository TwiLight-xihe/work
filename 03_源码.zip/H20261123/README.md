# 个人健康管理 Agent（赛道 A · AI 原生）

HarmonyOS 7 (API 26) · ArkTS + ArkUI · Stage 模型 · DevEco Studio 26.0.0.x

面向需要记录运动、饮食和睡眠的学生，提供**非医疗性质**的生活方式建议。已完成：
- 记录/建议的 **Preferences 本地持久化**（退出重启数据不丢失）；
- **真实云端 AI 接入**（OpenAI 兼容协议，可切换 DeepSeek / 通义千问 / 智谱 / Kimi / 百度千帆），未配置 Key 或调用失败时自动**本地降级**，保证演示稳定闭环。

## 一、目录结构与分层职责

```
entry/src/main/ets/
├── entryability/EntryAbility.ets       # 入口：注入全局 Context
├── pages/                              # 视图层（UI + 页面状态）
│   ├── Index.ets                       # 首页仪表盘 + Navigation 路由 + 跨页刷新监听
│   ├── RecordPage.ets                  # 记录页：三类记录完整 CRUD（持久化）
│   ├── AiAdvicePage.ets                # AI 分析/建议：云端+降级、上下文问答、历史
│   └── FoodCameraPage.ets              # 拍照识别：相册/样例 + 视觉降级
├── service/                            # 服务层（业务编排 + 数据来源）
│   ├── HealthDataService.ets           # 数据门面（页面入口，委托 Repository）
│   ├── HealthRepository.ets            # 持久化仓库（Preferences + JSON）
│   ├── StorageService.ets              # Preferences 底层封装
│   ├── HealthAiService.ets             # 云端 AI：http 请求/解析/状态码/视觉降级
│   └── AiAdviceService.ets             # 业务编排：提示词拼接/上下文/降级/历史
├── model/                              # 模型层（纯数据结构）
│   ├── HealthModels.ets                # 记录/汇总/建议/识别结果
│   ├── AiModels.ets                    # ChatMessage/响应体/AiServiceError
│   └── PageParams.ets                  # 页面名 + 路由参数
└── common/                             # 通用工具层
    ├── Config.ets                      # 集中配置：AI（多厂商对照）+ 存储 Key
    ├── GlobalContext.ets               # 全局 UIAbilityContext 持有器
    ├── DataEvents.ets                  # AppStorage 版本号（跨页刷新）
    ├── Constants.ets / Logger.ets      # 常量 / hilog 封装
    ├── DateUtil.ets                    # 日期/ID/睡眠时长
    └── AsyncUtil.ets                   # 延迟 + 超时工具
```

分层原则：**页面 → 服务 → 仓库 → 存储**；`common` 仅提供无业务依赖能力。

## 二、权限

`entry/src/main/module.json5` 已声明 `ohos.permission.INTERNET`（`reason` 引用 `string.json` 的 `internet_permission_reason`）。

## 三、云端 AI 配置（Config.ets）

- `AiConfig.BASE_URL / CHAT_PATH / MODEL`：默认 DeepSeek（`deepseek-chat`），注释内附通义千问、智谱清言、Kimi、百度千帆对照配置。
- `AiConfig.API_KEY`：**仅占位符 `sk-REPLACE_WITH_YOUR_API_KEY`**，填写真实 Key 后即走云端；`isApiKeyConfigured()` 判断是否已配置。
- 未配置 Key 或云端调用失败（网络/超时/401/402/400/404 等）时，自动降级为本地规则建议，并在建议卡中标注「本地降级建议」及原因。

## 四、本地持久化

- `StorageService` 封装 `preferences`（`@kit.ArkData`），统一 `put/flush/get`。
- `HealthRepository` 用 JSON 字符串保存三类记录与建议历史，读取时对异常/损坏数据兜底返回空数组，不崩溃。
- 记录/建议在退出或重启模拟器后仍保留；首次启动仅预置一次演示数据。

## 五、运行与联调

1. DevEco Studio 26.0.0.x 打开工程，Sync 后选择 Phone 模拟器运行。
2. 修改 `entry/src/main/module.json5`（权限）或 `common/Config.ets`（AI 配置）后，建议**卸载重装**或重启模拟器验证。
3. 常见故障排查见 [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)。

## 六、安全提示

- 严禁在代码、日志、注释、文档中出现真实 API Key；日志统一走 `Logger`，不输出密钥/密码/敏感个人数据。
- 所有 AI 建议均为非医疗性质，并附带免责声明。
