import http from "@ohos:net.http";
import { AiServiceError } from "@normalized:N&&&entry/src/main/ets/model/AiModels&";
import type { ChatMessage, ChatCompletionResponse, ChatRequestBody } from "@normalized:N&&&entry/src/main/ets/model/AiModels&";
import type { FoodRecognitionResult } from '../model/HealthModels';
import { AiConfig } from "@normalized:N&&&entry/src/main/ets/common/Config&";
import { Logger } from "@normalized:N&&&entry/src/main/ets/common/Logger&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
/**
 * 云端 AI 服务（service 层，真实 HTTP 接入）。
 * 使用 @kit.NetworkKit 的 http 模块发起 HTTPS POST，兼容 OpenAI chat/completions 协议。
 */
export class HealthAiService {
    private static instance: HealthAiService | null = null;
    static getInstance(): HealthAiService {
        if (HealthAiService.instance === null) {
            HealthAiService.instance = new HealthAiService();
        }
        return HealthAiService.instance;
    }
    private constructor() {
    }
    /**
     * 对话补全（OpenAI 兼容）。
     * @param messages 完整消息数组（含 system / user / assistant 历史，用于上下文追问）
     */
    async chat(messages: ChatMessage[]): Promise<string> {
        const request = http.createHttp();
        let httpError: boolean = false;
        let response: http.HttpResponse | null = null;
        try {
            const bodyObj: ChatRequestBody = {
                model: AiConfig.MODEL,
                messages: messages,
                stream: false
            };
            const body: string = JSON.stringify(bodyObj);
            const headers: Record<string, string> = {};
            headers['Content-Type'] = 'application/json';
            headers['Authorization'] = 'Bearer ' + AiConfig.API_KEY;
            const url: string = AiConfig.BASE_URL + AiConfig.CHAT_PATH;
            Logger.info(Constants.TAG_SERVICE, 'ai chat request start, model=' + AiConfig.MODEL);
            response = await request.request(url, {
                method: http.RequestMethod.POST,
                header: headers,
                extraData: body,
                expectDataType: http.HttpDataType.STRING,
                connectTimeout: AiConfig.CONNECT_TIMEOUT,
                readTimeout: AiConfig.READ_TIMEOUT
            });
        }
        catch (e) {
            httpError = true;
            Logger.error(Constants.TAG_SERVICE, 'ai chat network/timeout error');
        }
        finally {
            request.destroy();
            Logger.info(Constants.TAG_SERVICE, 'ai chat request destroyed');
        }
        if (httpError) {
            throw new AiServiceError(-1, '网络请求失败或超时，请检查网络后重试');
        }
        if (response === null) {
            throw new AiServiceError(-1, '网络请求失败或超时，请检查网络后重试');
        }
        const statusCode: number = response.responseCode as number;
        Logger.info(Constants.TAG_SERVICE, 'ai chat response status=' + statusCode.toString());
        if (statusCode !== 200) {
            throw new AiServiceError(statusCode, this.friendlyHttpError(statusCode));
        }
        const raw: string = response.result as string;
        return this.parseContent(raw);
    }
    /** 解析 choices[0].message.content */
    private parseContent(raw: string): string {
        let content: string = '';
        try {
            const data = JSON.parse(raw) as ChatCompletionResponse;
            const choices = data.choices;
            if (choices !== undefined && choices !== null && choices.length > 0) {
                const message = choices[0].message;
                if (message !== undefined && message !== null) {
                    content = message.content;
                }
            }
        }
        catch (e) {
            Logger.error(Constants.TAG_SERVICE, 'ai response parse error');
            throw new AiServiceError(-2, 'AI 返回内容解析失败，请稍后重试');
        }
        if (content.trim() === '') {
            throw new AiServiceError(-2, 'AI 未返回有效内容，请稍后重试');
        }
        return content;
    }
    /** 将 HTTP 状态码转为友好提示 */
    private friendlyHttpError(code: number): string {
        if (code === 401) {
            return '鉴权失败（401）：API Key 无效或已过期';
        }
        if (code === 402) {
            return '账户余额不足（402）：请为 AI 账户充值后重试';
        }
        if (code === 400) {
            return '请求参数错误（400）：请检查请求体与模型名称';
        }
        if (code === 404) {
            return '接口不存在（404）：请检查 baseUrl 与接口路径';
        }
        if (code === 429) {
            return '请求过于频繁（429）：请稍后重试';
        }
        if (code >= 500) {
            return 'AI 服务端异常（' + code.toString() + '）：请稍后重试';
        }
        return 'AI 请求失败（' + code.toString() + '）：请稍后重试';
    }
    /**
     * 食物视觉识别（多模态接口封装）。
     * 真实接入：将图片转 base64 后 POST 到视觉模型接口（如 Qwen-VL / GPT-4V），
     * 请求体示例：
     * {
     *   "model": "qwen-vl-plus",
     *   "messages": [{
     *     "role": "user",
     *     "content": [
     *       { "type": "text", "text": "这是什么食物？请给出名称与大致热量" },
     *       { "type": "image_url", "image_url": { "url": "data:image/png;base64,xxxx" } }
     *     ]
     *   }]
     * }
     * 当前未配置视觉模型，走本地启发式降级，保证业务闭环仍可演示。
     */
    async analyzeFoodVision(imageUri: string): Promise<FoodRecognitionResult> {
        return this.localFoodRecognition(imageUri);
    }
    private localFoodRecognition(imageUri: string): FoodRecognitionResult {
        const food: string = this.guessFoodFromUri(imageUri);
        let calories: number = 0;
        let suggestion: string = '';
        if (food === '苹果') {
            calories = 52;
            suggestion = '苹果富含膳食纤维，适合作为加餐，注意控制总量。';
        }
        else if (food === '米饭') {
            calories = 116;
            suggestion = '米饭是主食，建议搭配蔬菜与蛋白质，控制精制碳水比例。';
        }
        else if (food === '牛奶') {
            calories = 54;
            suggestion = '牛奶提供优质蛋白与钙，建议每天适量摄入。';
        }
        else {
            calories = 150;
            suggestion = '无法精确识别该食物，建议手动录入以估算热量。';
        }
        const result: FoodRecognitionResult = {
            foodName: food,
            confidence: food === '未知食物' ? 0.4 : 0.92,
            estimatedCalories: calories,
            summary: '识别结果：' + food + '（每 100g 约 ' + calories.toString() + ' 千卡）',
            suggestion: suggestion,
            imageUri: imageUri,
            degraded: true
        };
        return result;
    }
    private guessFoodFromUri(uri: string): string {
        const lower: string = uri.toLowerCase();
        if (lower.indexOf('apple') >= 0 || lower.indexOf('苹果') >= 0) {
            return '苹果';
        }
        if (lower.indexOf('rice') >= 0 || lower.indexOf('米饭') >= 0) {
            return '米饭';
        }
        if (lower.indexOf('milk') >= 0 || lower.indexOf('牛奶') >= 0) {
            return '牛奶';
        }
        return '未知食物';
    }
}
