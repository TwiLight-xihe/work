import type { RecordType } from './HealthModels';
/**
 * 页面名称常量。
 * 与 Index 中 navDestination 的 PageMap 分支保持一致，避免魔法字符串。
 */
export class PageName {
    static readonly RECORD: string = 'RecordPage';
    static readonly AI_ADVICE: string = 'AiAdvicePage';
    static readonly FOOD_CAMERA: string = 'FoodCameraPage';
}
/**
 * 记录页路由参数（使用 Navigation 的 pushPathByName 传递）。
 * 字段全部可选：调用方可以不传任何参数，页面自行兜底默认值。
 */
export interface RecordPageParams {
    recordType?: RecordType;
}
