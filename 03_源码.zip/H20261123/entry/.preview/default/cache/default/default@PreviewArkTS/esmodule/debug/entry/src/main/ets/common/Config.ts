/**
 * 集中配置（common 层）。
 * 严禁在此处或任何日志 / 注释 / 文档中出现真实 API Key。
 */
export class AiConfig {
    // ============ 厂商对照（均兼容 OpenAI chat/completions 协议）============
    // DeepSeek:   BASE_URL=https://api.deepseek.com            CHAT_PATH=/v1/chat/completions        MODEL=deepseek-chat
    // 通义千问:   BASE_URL=https://dashscope.aliyuncs.com/compatible-mode  CHAT_PATH=/v1/chat/completions  MODEL=qwen-plus
    // 智谱清言:   BASE_URL=https://open.bigmodel.cn            CHAT_PATH=/api/paas/v4/chat/completions  MODEL=glm-4-flash
    // Kimi:       BASE_URL=https://api.moonshot.cn             CHAT_PATH=/v1/chat/completions        MODEL=moonshot-v1-8k
    // 百度千帆:   BASE_URL=https://qianfan.baidubce.com        CHAT_PATH=/v2/chat/completions        MODEL=ernie-4.0-turbo-8k
    //
    // 切换厂商只需修改 BASE_URL / CHAT_PATH / MODEL 三项。
    static readonly BASE_URL: string = 'https://api.deepseek.com';
    static readonly CHAT_PATH: string = '/v1/chat/completions';
    static readonly MODEL: string = 'deepseek-chat';
    // 占位符：仅用于编译与联调，严禁提交真实密钥
    static readonly API_KEY: string = 'sk-REPLACE_WITH_YOUR_API_KEY';
    // 超时（毫秒）
    static readonly CONNECT_TIMEOUT: number = 10000;
    static readonly READ_TIMEOUT: number = 30000;
    // 系统提示词：限定「非医疗性质」的输出边界
    static readonly SYSTEM_PROMPT: string = '你是一名面向学生的个人健康管理助手。请基于用户提供的运动、饮食、睡眠记录，' +
        '生成简短、友好、非医疗性质的摘要与生活方式建议。要求：' +
        '1) 不提供任何医疗诊断、治疗或用药建议；' +
        '2) 语气积极、鼓励；' +
        '3) 建议末尾包含「以上建议仅供参考，不构成医疗建议」；' +
        '4) 使用中文回答。';
    /** 是否已配置真实 API Key（非空且非占位符） */
    static isApiKeyConfigured(): boolean {
        const key: string = AiConfig.API_KEY;
        return key !== '' && key.indexOf('REPLACE') < 0;
    }
}
/**
 * 本地持久化相关配置。
 */
export class StorageConfig {
    static readonly PREF_NAME: string = 'health_agent_store';
    static readonly KEY_EXERCISE: string = 'exercise_list';
    static readonly KEY_DIET: string = 'diet_list';
    static readonly KEY_SLEEP: string = 'sleep_list';
    static readonly KEY_ADVICE: string = 'advice_history';
    static readonly KEY_SEEDED: string = 'seeded';
}
