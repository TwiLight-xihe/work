/**
 * 日期时间工具类（common 层）。
 */
export class DateUtil {
    /** 两位补零 */
    static pad2(n: number): string {
        if (n < 10) {
            return '0' + n.toString();
        }
        return n.toString();
    }
    /** 返回 yyyy-MM-dd */
    static today(): string {
        return DateUtil.formatDate(new Date());
    }
    /** 返回 yyyy-MM-dd HH:mm:ss */
    static now(): string {
        return DateUtil.formatDateTime(new Date());
    }
    static formatDate(d: Date): string {
        return d.getFullYear().toString() + '-' +
            DateUtil.pad2(d.getMonth() + 1) + '-' +
            DateUtil.pad2(d.getDate());
    }
    static formatDateTime(d: Date): string {
        return DateUtil.formatDate(d) + ' ' +
            DateUtil.pad2(d.getHours()) + ':' +
            DateUtil.pad2(d.getMinutes()) + ':' +
            DateUtil.pad2(d.getSeconds());
    }
    /** 返回 HH:mm */
    static formatTime(d: Date): string {
        return DateUtil.pad2(d.getHours()) + ':' + DateUtil.pad2(d.getMinutes());
    }
    /** 生成本地唯一 ID（真实云端接入后由服务端生成） */
    static genId(prefix: string): string {
        return prefix + '_' + Date.now().toString() + '_' +
            Math.floor(Math.random() * 100000).toString();
    }
    /** 将 HH:mm 转为从 0 点开始的分钟数 */
    static toMinutes(hhmm: string): number {
        if (hhmm.length < 5) {
            return 0;
        }
        const hourStr: string = hhmm.substring(0, 2);
        const minStr: string = hhmm.substring(3, 5);
        const hour: number = Number(hourStr);
        const minute: number = Number(minStr);
        if (isNaN(hour) || isNaN(minute)) {
            return 0;
        }
        return hour * 60 + minute;
    }
    /** 计算睡眠时长（小时，保留一位小数），支持跨零点 */
    static sleepHours(bedTime: string, wakeTime: string): number {
        const bedMin: number = DateUtil.toMinutes(bedTime);
        const wakeMin: number = DateUtil.toMinutes(wakeTime);
        let diff: number = wakeMin - bedMin;
        if (diff < 0) {
            diff = diff + 24 * 60;
        }
        if (diff === 0) {
            diff = 24 * 60;
        }
        return Math.round((diff / 60) * 10) / 10;
    }
}
