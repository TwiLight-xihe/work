import preferences from "@ohos:data.preferences";
import { GlobalContext } from "@normalized:N&&&entry/src/main/ets/common/GlobalContext&";
import { StorageConfig } from "@normalized:N&&&entry/src/main/ets/common/Config&";
import { Logger } from "@normalized:N&&&entry/src/main/ets/common/Logger&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
/**
 * Preferences 持久化封装（service 层最底层）。
 * 统一处理获取/写入/flush，上层 Repository 只关心业务对象序列化。
 */
export class StorageService {
    private static prefs: preferences.Preferences | null = null;
    private static async getPrefs(): Promise<preferences.Preferences> {
        if (StorageService.prefs === null) {
            const ctx = GlobalContext.getContext();
            if (ctx === null) {
                throw new Error('StorageService: context not ready');
            }
            StorageService.prefs = await preferences.getPreferences(ctx, { name: StorageConfig.PREF_NAME });
            Logger.info(Constants.TAG_SERVICE, 'preferences initialized: ' + StorageConfig.PREF_NAME);
        }
        return StorageService.prefs;
    }
    static async putString(key: string, value: string): Promise<void> {
        const prefs = await StorageService.getPrefs();
        await prefs.put(key, value);
        await prefs.flush();
        Logger.info(Constants.TAG_SERVICE, 'storage putString key=' + key);
    }
    static async getString(key: string, defaultValue: string): Promise<string> {
        const prefs = await StorageService.getPrefs();
        const value = await prefs.get(key, defaultValue);
        return value as string;
    }
    static async putBoolean(key: string, value: boolean): Promise<void> {
        const prefs = await StorageService.getPrefs();
        await prefs.put(key, value);
        await prefs.flush();
    }
    static async getBoolean(key: string, defaultValue: boolean): Promise<boolean> {
        const prefs = await StorageService.getPrefs();
        const value = await prefs.get(key, defaultValue);
        return value as boolean;
    }
    static async remove(key: string): Promise<void> {
        const prefs = await StorageService.getPrefs();
        await prefs.delete(key);
        await prefs.flush();
        Logger.info(Constants.TAG_SERVICE, 'storage remove key=' + key);
    }
}
