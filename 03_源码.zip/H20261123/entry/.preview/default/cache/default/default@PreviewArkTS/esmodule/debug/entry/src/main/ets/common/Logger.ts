import hilog from "@ohos:hilog";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
/**
 * 统一日志封装（common 层）。
 * 所有日志统一走 hilog，严禁输出敏感信息 / 密钥 / 用户隐私原文。
 */
export class Logger {
    static debug(tag: string, message: string): void {
        hilog.debug(Constants.DOMAIN, tag, '%{public}s', message);
    }
    static info(tag: string, message: string): void {
        hilog.info(Constants.DOMAIN, tag, '%{public}s', message);
    }
    static warn(tag: string, message: string): void {
        hilog.warn(Constants.DOMAIN, tag, '%{public}s', message);
    }
    static error(tag: string, message: string): void {
        hilog.error(Constants.DOMAIN, tag, '%{public}s', message);
    }
}
