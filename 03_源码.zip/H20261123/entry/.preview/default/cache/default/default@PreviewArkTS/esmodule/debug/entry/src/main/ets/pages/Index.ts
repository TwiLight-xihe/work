if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    pathStack?: NavPathStack;
    summary?: DailySummary;
    loading?: boolean;
    loadError?: boolean;
    dataVersion?: number;
}
import type { DailySummary } from '../model/HealthModels';
import { PageName } from "@normalized:N&&&entry/src/main/ets/model/PageParams&";
import type { RecordPageParams } from "@normalized:N&&&entry/src/main/ets/model/PageParams&";
import { HealthDataService } from "@normalized:N&&&entry/src/main/ets/service/HealthDataService&";
import { DateUtil } from "@normalized:N&&&entry/src/main/ets/common/DateUtil&";
import { Logger } from "@normalized:N&&&entry/src/main/ets/common/Logger&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
import { RecordPage } from "@normalized:N&&&entry/src/main/ets/pages/RecordPage&";
import { AiAdvicePage } from "@normalized:N&&&entry/src/main/ets/pages/AiAdvicePage&";
import { FoodCameraPage } from "@normalized:N&&&entry/src/main/ets/pages/FoodCameraPage&";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__pathStack = new ObservedPropertyObjectPU(new NavPathStack(), this, "pathStack");
        this.addProvidedVar("pathStack", this.__pathStack, false);
        this.__summary = new ObservedPropertyObjectPU(HealthDataService.getInstance().emptySummary(), this, "summary");
        this.__loading = new ObservedPropertySimplePU(true, this, "loading");
        this.__loadError = new ObservedPropertySimplePU(false, this, "loadError");
        this.__dataVersion = this.createStorageLink('healthDataVersion', 0, "dataVersion");
        this.setInitiallyProvidedValue(params);
        this.declareWatch("dataVersion", this.onDataVersionChanged);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.pathStack !== undefined) {
            this.pathStack = params.pathStack;
        }
        if (params.summary !== undefined) {
            this.summary = params.summary;
        }
        if (params.loading !== undefined) {
            this.loading = params.loading;
        }
        if (params.loadError !== undefined) {
            this.loadError = params.loadError;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__pathStack.purgeDependencyOnElmtId(rmElmtId);
        this.__summary.purgeDependencyOnElmtId(rmElmtId);
        this.__loading.purgeDependencyOnElmtId(rmElmtId);
        this.__loadError.purgeDependencyOnElmtId(rmElmtId);
        this.__dataVersion.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__pathStack.aboutToBeDeleted();
        this.__summary.aboutToBeDeleted();
        this.__loading.aboutToBeDeleted();
        this.__loadError.aboutToBeDeleted();
        this.__dataVersion.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __pathStack: ObservedPropertyObjectPU<NavPathStack>;
    get pathStack() {
        return this.__pathStack.get();
    }
    set pathStack(newValue: NavPathStack) {
        this.__pathStack.set(newValue);
    }
    private __summary: ObservedPropertyObjectPU<DailySummary>;
    get summary() {
        return this.__summary.get();
    }
    set summary(newValue: DailySummary) {
        this.__summary.set(newValue);
    }
    private __loading: ObservedPropertySimplePU<boolean>;
    get loading() {
        return this.__loading.get();
    }
    set loading(newValue: boolean) {
        this.__loading.set(newValue);
    }
    private __loadError: ObservedPropertySimplePU<boolean>;
    get loadError() {
        return this.__loadError.get();
    }
    set loadError(newValue: boolean) {
        this.__loadError.set(newValue);
    }
    private __dataVersion: ObservedPropertyAbstractPU<number>;
    get dataVersion() {
        return this.__dataVersion.get();
    }
    set dataVersion(newValue: number) {
        this.__dataVersion.set(newValue);
    }
    aboutToAppear(): void {
        this.refreshSummary();
    }
    private onDataVersionChanged(): void {
        Logger.info(Constants.TAG_INDEX, 'data version changed, refresh summary');
        this.refreshSummary();
    }
    private async refreshSummary(): Promise<void> {
        this.loading = true;
        this.loadError = false;
        try {
            this.summary = await HealthDataService.getInstance().getDailySummary();
            Logger.info(Constants.TAG_INDEX, 'refresh summary ok');
        }
        catch (e) {
            this.loadError = true;
            this.summary = HealthDataService.getInstance().emptySummary();
            Logger.error(Constants.TAG_INDEX, 'refresh summary failed');
        }
        finally {
            this.loading = false;
        }
    }
    private goRecord(): void {
        const params: RecordPageParams = {};
        this.pathStack.pushPathByName(PageName.RECORD, params, true);
    }
    private goAdvice(): void {
        this.pathStack.pushPathByName(PageName.AI_ADVICE, undefined, true);
    }
    private goCamera(): void {
        this.pathStack.pushPathByName(PageName.FOOD_CAMERA, undefined, true);
    }
    PageMap(name: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (name === PageName.RECORD) {
                this.ifElseBranchUpdateFunction(0, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new RecordPage(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 64, col: 7 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {};
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "RecordPage" });
                    }
                });
            }
            else if (name === PageName.AI_ADVICE) {
                this.ifElseBranchUpdateFunction(1, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new AiAdvicePage(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 66, col: 7 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {};
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "AiAdvicePage" });
                    }
                });
            }
            else if (name === PageName.FOOD_CAMERA) {
                this.ifElseBranchUpdateFunction(2, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new FoodCameraPage(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 68, col: 7 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {};
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "FoodCameraPage" });
                    }
                });
            }
            else {
                this.ifElseBranchUpdateFunction(3, () => {
                });
            }
        }, If);
        If.pop();
    }
    SummaryCard(title: string, value: string, unit: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(74:5)", "entry");
            Column.layoutWeight(1);
            Column.padding(14);
            Column.borderRadius(12);
            Column.backgroundColor('#FFFFFF');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(75:7)", "entry");
            Text.fontSize(13);
            Text.fontColor('#666666');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(value);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(78:7)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#1677FF');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(unit);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(82:7)", "entry");
            Text.fontSize(11);
            Text.fontColor('#999999');
        }, Text);
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Navigation.create(this.pathStack, { moduleName: "entry", pagePath: "entry/src/main/ets/pages/Index", isUserCreateStack: true });
            Navigation.debugLine("entry/src/main/ets/pages/Index.ets(94:5)", "entry");
            Navigation.mode(NavigationMode.Stack);
            Navigation.title('首页');
            Navigation.hideToolBar(true);
            Navigation.navDestination({ builder: this.PageMap.bind(this) });
        }, Navigation);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/Index.ets(95:7)", "entry");
            Scroll.width('100%');
            Scroll.height('100%');
            Scroll.backgroundColor('#F5F6F7');
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(96:9)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor('#F5F6F7');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部标题
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(98:11)", "entry");
            // 顶部标题
            Column.width('100%');
            // 顶部标题
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('个人健康管理 Agent');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(99:13)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#333333');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(DateUtil.today() + ' · 今天也要照顾好自己');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(103:13)", "entry");
            Text.fontSize(13);
            Text.fontColor('#999999');
        }, Text);
        Text.pop();
        // 顶部标题
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 当日概览
            if (this.loading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 8 });
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(112:13)", "entry");
                        Column.width('100%');
                        Column.padding(20);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/Index.ets(113:15)", "entry");
                        LoadingProgress.width(36);
                        LoadingProgress.height(36);
                        LoadingProgress.color('#1677FF');
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('加载中…');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(117:15)", "entry");
                        Text.fontSize(13);
                        Text.fontColor('#999999');
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.loadError) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 8 });
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(125:13)", "entry");
                        Column.width('100%');
                        Column.padding(20);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('数据加载失败');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(126:15)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#666666');
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('重试');
                        Button.debugLine("entry/src/main/ets/pages/Index.ets(129:15)", "entry");
                        Button.fontSize(13);
                        Button.onClick(() => {
                            this.refreshSummary();
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create({ space: 10 });
                        Row.debugLine("entry/src/main/ets/pages/Index.ets(139:13)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.SummaryCard.bind(this)('运动', this.summary.exerciseMinutes.toString(), '分钟');
                    this.SummaryCard.bind(this)('摄入', this.summary.dietCalories.toString(), '千卡');
                    this.SummaryCard.bind(this)('睡眠', this.summary.sleepHours.toString(), '小时');
                    Row.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 快捷入口
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(148:11)", "entry");
            // 快捷入口
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(149:13)", "entry");
            Row.width('100%');
            Row.padding(16);
            Row.borderRadius(12);
            Row.backgroundColor('#FFFFFF');
            Row.onClick(() => {
                this.goRecord();
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 2 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(150:15)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('记录管理');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(151:17)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor('#333333');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('运动 / 饮食 / 睡眠的增删改查');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(155:17)", "entry");
            Text.fontSize(12);
            Text.fontColor('#999999');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(161:15)", "entry");
            Text.fontSize(18);
            Text.fontColor('#CCCCCC');
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(173:13)", "entry");
            Row.width('100%');
            Row.padding(16);
            Row.borderRadius(12);
            Row.backgroundColor('#FFFFFF');
            Row.onClick(() => {
                this.goAdvice();
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 2 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(174:15)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('AI 分析建议');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(175:17)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor('#333333');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('生成今日健康分析与智能问答');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(179:17)", "entry");
            Text.fontSize(12);
            Text.fontColor('#999999');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(185:15)", "entry");
            Text.fontSize(18);
            Text.fontColor('#CCCCCC');
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(197:13)", "entry");
            Row.width('100%');
            Row.padding(16);
            Row.borderRadius(12);
            Row.backgroundColor('#FFFFFF');
            Row.onClick(() => {
                this.goCamera();
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 2 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(198:15)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('拍照识别');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(199:17)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor('#333333');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('拍照或导入样例食物图片');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(203:17)", "entry");
            Text.fontSize(12);
            Text.fontColor('#999999');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(209:15)", "entry");
            Text.fontSize(18);
            Text.fontColor('#CCCCCC');
        }, Text);
        Text.pop();
        Row.pop();
        // 快捷入口
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 页脚提示
            Text.create('提示：所有建议均为非医疗性质，仅供参考。');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(224:11)", "entry");
            // 页脚提示
            Text.fontSize(12);
            // 页脚提示
            Text.fontColor('#AAAAAA');
            // 页脚提示
            Text.width('100%');
        }, Text);
        // 页脚提示
        Text.pop();
        Column.pop();
        Scroll.pop();
        Navigation.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public __resetStateVarsOnReuse__Internal(params: Object): void {
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.h20261123", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
