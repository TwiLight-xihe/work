if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface RecordPage_Params {
    pathStack?: NavPathStack;
    currentType?: RecordType;
    loading?: boolean;
    loadError?: boolean;
    exerciseList?: ExerciseRecord[];
    dietList?: DietRecord[];
    sleepList?: SleepRecord[];
    editing?: boolean;
    editingId?: string;
    formDate?: string;
    formNote?: string;
    formExerciseTypeIndex?: number;
    formDuration?: string;
    formCalories?: string;
    formDistance?: string;
    formMealTypeIndex?: number;
    formFoodName?: string;
    formDietCalories?: string;
    formBedTime?: string;
    formWakeTime?: string;
    formSleepQualityIndex?: number;
    exerciseOptions?: SelectOption[];
    mealOptions?: SelectOption[];
    qualityOptions?: SelectOption[];
}
import promptAction from "@ohos:promptAction";
import { RecordType } from "@normalized:N&&&entry/src/main/ets/model/HealthModels&";
import type { ExerciseRecord, DietRecord, SleepRecord } from "@normalized:N&&&entry/src/main/ets/model/HealthModels&";
import { PageName } from "@normalized:N&&&entry/src/main/ets/model/PageParams&";
import type { RecordPageParams } from "@normalized:N&&&entry/src/main/ets/model/PageParams&";
import { HealthDataService } from "@normalized:N&&&entry/src/main/ets/service/HealthDataService&";
import { DateUtil } from "@normalized:N&&&entry/src/main/ets/common/DateUtil&";
import { Logger } from "@normalized:N&&&entry/src/main/ets/common/Logger&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
import { DataEvents } from "@normalized:N&&&entry/src/main/ets/common/DataEvents&";
export class RecordPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__pathStack = this.initializeConsume('pathStack', "pathStack");
        this.__currentType = new ObservedPropertySimplePU(RecordType.EXERCISE, this, "currentType");
        this.__loading = new ObservedPropertySimplePU(true, this, "loading");
        this.__loadError = new ObservedPropertySimplePU(false, this, "loadError");
        this.__exerciseList = new ObservedPropertyObjectPU([], this, "exerciseList");
        this.__dietList = new ObservedPropertyObjectPU([], this, "dietList");
        this.__sleepList = new ObservedPropertyObjectPU([], this, "sleepList");
        this.__editing = new ObservedPropertySimplePU(false, this, "editing");
        this.__editingId = new ObservedPropertySimplePU('', this, "editingId");
        this.__formDate = new ObservedPropertySimplePU('', this, "formDate");
        this.__formNote = new ObservedPropertySimplePU('', this, "formNote");
        this.__formExerciseTypeIndex = new ObservedPropertySimplePU(0, this, "formExerciseTypeIndex");
        this.__formDuration = new ObservedPropertySimplePU('', this, "formDuration");
        this.__formCalories = new ObservedPropertySimplePU('', this, "formCalories");
        this.__formDistance = new ObservedPropertySimplePU('', this, "formDistance");
        this.__formMealTypeIndex = new ObservedPropertySimplePU(0, this, "formMealTypeIndex");
        this.__formFoodName = new ObservedPropertySimplePU('', this, "formFoodName");
        this.__formDietCalories = new ObservedPropertySimplePU('', this, "formDietCalories");
        this.__formBedTime = new ObservedPropertySimplePU('23:00', this, "formBedTime");
        this.__formWakeTime = new ObservedPropertySimplePU('07:00', this, "formWakeTime");
        this.__formSleepQualityIndex = new ObservedPropertySimplePU(0, this, "formSleepQualityIndex");
        this.exerciseOptions = [
            { value: '跑步' },
            { value: '步行' },
            { value: '骑行' },
            { value: '球类' },
            { value: '其他' }
        ];
        this.mealOptions = [
            { value: '早餐' },
            { value: '午餐' },
            { value: '晚餐' },
            { value: '加餐' }
        ];
        this.qualityOptions = [
            { value: '优秀' },
            { value: '良好' },
            { value: '一般' },
            { value: '较差' }
        ];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: RecordPage_Params) {
        if (params.currentType !== undefined) {
            this.currentType = params.currentType;
        }
        if (params.loading !== undefined) {
            this.loading = params.loading;
        }
        if (params.loadError !== undefined) {
            this.loadError = params.loadError;
        }
        if (params.exerciseList !== undefined) {
            this.exerciseList = params.exerciseList;
        }
        if (params.dietList !== undefined) {
            this.dietList = params.dietList;
        }
        if (params.sleepList !== undefined) {
            this.sleepList = params.sleepList;
        }
        if (params.editing !== undefined) {
            this.editing = params.editing;
        }
        if (params.editingId !== undefined) {
            this.editingId = params.editingId;
        }
        if (params.formDate !== undefined) {
            this.formDate = params.formDate;
        }
        if (params.formNote !== undefined) {
            this.formNote = params.formNote;
        }
        if (params.formExerciseTypeIndex !== undefined) {
            this.formExerciseTypeIndex = params.formExerciseTypeIndex;
        }
        if (params.formDuration !== undefined) {
            this.formDuration = params.formDuration;
        }
        if (params.formCalories !== undefined) {
            this.formCalories = params.formCalories;
        }
        if (params.formDistance !== undefined) {
            this.formDistance = params.formDistance;
        }
        if (params.formMealTypeIndex !== undefined) {
            this.formMealTypeIndex = params.formMealTypeIndex;
        }
        if (params.formFoodName !== undefined) {
            this.formFoodName = params.formFoodName;
        }
        if (params.formDietCalories !== undefined) {
            this.formDietCalories = params.formDietCalories;
        }
        if (params.formBedTime !== undefined) {
            this.formBedTime = params.formBedTime;
        }
        if (params.formWakeTime !== undefined) {
            this.formWakeTime = params.formWakeTime;
        }
        if (params.formSleepQualityIndex !== undefined) {
            this.formSleepQualityIndex = params.formSleepQualityIndex;
        }
        if (params.exerciseOptions !== undefined) {
            this.exerciseOptions = params.exerciseOptions;
        }
        if (params.mealOptions !== undefined) {
            this.mealOptions = params.mealOptions;
        }
        if (params.qualityOptions !== undefined) {
            this.qualityOptions = params.qualityOptions;
        }
    }
    updateStateVars(params: RecordPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__pathStack.purgeDependencyOnElmtId(rmElmtId);
        this.__currentType.purgeDependencyOnElmtId(rmElmtId);
        this.__loading.purgeDependencyOnElmtId(rmElmtId);
        this.__loadError.purgeDependencyOnElmtId(rmElmtId);
        this.__exerciseList.purgeDependencyOnElmtId(rmElmtId);
        this.__dietList.purgeDependencyOnElmtId(rmElmtId);
        this.__sleepList.purgeDependencyOnElmtId(rmElmtId);
        this.__editing.purgeDependencyOnElmtId(rmElmtId);
        this.__editingId.purgeDependencyOnElmtId(rmElmtId);
        this.__formDate.purgeDependencyOnElmtId(rmElmtId);
        this.__formNote.purgeDependencyOnElmtId(rmElmtId);
        this.__formExerciseTypeIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__formDuration.purgeDependencyOnElmtId(rmElmtId);
        this.__formCalories.purgeDependencyOnElmtId(rmElmtId);
        this.__formDistance.purgeDependencyOnElmtId(rmElmtId);
        this.__formMealTypeIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__formFoodName.purgeDependencyOnElmtId(rmElmtId);
        this.__formDietCalories.purgeDependencyOnElmtId(rmElmtId);
        this.__formBedTime.purgeDependencyOnElmtId(rmElmtId);
        this.__formWakeTime.purgeDependencyOnElmtId(rmElmtId);
        this.__formSleepQualityIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__pathStack.aboutToBeDeleted();
        this.__currentType.aboutToBeDeleted();
        this.__loading.aboutToBeDeleted();
        this.__loadError.aboutToBeDeleted();
        this.__exerciseList.aboutToBeDeleted();
        this.__dietList.aboutToBeDeleted();
        this.__sleepList.aboutToBeDeleted();
        this.__editing.aboutToBeDeleted();
        this.__editingId.aboutToBeDeleted();
        this.__formDate.aboutToBeDeleted();
        this.__formNote.aboutToBeDeleted();
        this.__formExerciseTypeIndex.aboutToBeDeleted();
        this.__formDuration.aboutToBeDeleted();
        this.__formCalories.aboutToBeDeleted();
        this.__formDistance.aboutToBeDeleted();
        this.__formMealTypeIndex.aboutToBeDeleted();
        this.__formFoodName.aboutToBeDeleted();
        this.__formDietCalories.aboutToBeDeleted();
        this.__formBedTime.aboutToBeDeleted();
        this.__formWakeTime.aboutToBeDeleted();
        this.__formSleepQualityIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __pathStack: ObservedPropertyAbstractPU<NavPathStack>;
    get pathStack() {
        return this.__pathStack.get();
    }
    set pathStack(newValue: NavPathStack) {
        this.__pathStack.set(newValue);
    }
    private __currentType: ObservedPropertySimplePU<RecordType>;
    get currentType() {
        return this.__currentType.get();
    }
    set currentType(newValue: RecordType) {
        this.__currentType.set(newValue);
    }
    private __loading: ObservedPropertySimplePU<boolean>;
    get loading() {
        return this.__loading.get();
    }
    set loading(newValue: boolean) {
        this.__loading.set(newValue);
    }
    private __loadError: ObservedPropertySimplePU<boolean>;
    get loadError() {
        return this.__loadError.get();
    }
    set loadError(newValue: boolean) {
        this.__loadError.set(newValue);
    }
    private __exerciseList: ObservedPropertyObjectPU<ExerciseRecord[]>;
    get exerciseList() {
        return this.__exerciseList.get();
    }
    set exerciseList(newValue: ExerciseRecord[]) {
        this.__exerciseList.set(newValue);
    }
    private __dietList: ObservedPropertyObjectPU<DietRecord[]>;
    get dietList() {
        return this.__dietList.get();
    }
    set dietList(newValue: DietRecord[]) {
        this.__dietList.set(newValue);
    }
    private __sleepList: ObservedPropertyObjectPU<SleepRecord[]>;
    get sleepList() {
        return this.__sleepList.get();
    }
    set sleepList(newValue: SleepRecord[]) {
        this.__sleepList.set(newValue);
    }
    // 表单状态
    private __editing: ObservedPropertySimplePU<boolean>;
    get editing() {
        return this.__editing.get();
    }
    set editing(newValue: boolean) {
        this.__editing.set(newValue);
    }
    private __editingId: ObservedPropertySimplePU<string>;
    get editingId() {
        return this.__editingId.get();
    }
    set editingId(newValue: string) {
        this.__editingId.set(newValue);
    }
    private __formDate: ObservedPropertySimplePU<string>;
    get formDate() {
        return this.__formDate.get();
    }
    set formDate(newValue: string) {
        this.__formDate.set(newValue);
    }
    private __formNote: ObservedPropertySimplePU<string>;
    get formNote() {
        return this.__formNote.get();
    }
    set formNote(newValue: string) {
        this.__formNote.set(newValue);
    }
    private __formExerciseTypeIndex: ObservedPropertySimplePU<number>;
    get formExerciseTypeIndex() {
        return this.__formExerciseTypeIndex.get();
    }
    set formExerciseTypeIndex(newValue: number) {
        this.__formExerciseTypeIndex.set(newValue);
    }
    private __formDuration: ObservedPropertySimplePU<string>;
    get formDuration() {
        return this.__formDuration.get();
    }
    set formDuration(newValue: string) {
        this.__formDuration.set(newValue);
    }
    private __formCalories: ObservedPropertySimplePU<string>;
    get formCalories() {
        return this.__formCalories.get();
    }
    set formCalories(newValue: string) {
        this.__formCalories.set(newValue);
    }
    private __formDistance: ObservedPropertySimplePU<string>;
    get formDistance() {
        return this.__formDistance.get();
    }
    set formDistance(newValue: string) {
        this.__formDistance.set(newValue);
    }
    private __formMealTypeIndex: ObservedPropertySimplePU<number>;
    get formMealTypeIndex() {
        return this.__formMealTypeIndex.get();
    }
    set formMealTypeIndex(newValue: number) {
        this.__formMealTypeIndex.set(newValue);
    }
    private __formFoodName: ObservedPropertySimplePU<string>;
    get formFoodName() {
        return this.__formFoodName.get();
    }
    set formFoodName(newValue: string) {
        this.__formFoodName.set(newValue);
    }
    private __formDietCalories: ObservedPropertySimplePU<string>;
    get formDietCalories() {
        return this.__formDietCalories.get();
    }
    set formDietCalories(newValue: string) {
        this.__formDietCalories.set(newValue);
    }
    private __formBedTime: ObservedPropertySimplePU<string>;
    get formBedTime() {
        return this.__formBedTime.get();
    }
    set formBedTime(newValue: string) {
        this.__formBedTime.set(newValue);
    }
    private __formWakeTime: ObservedPropertySimplePU<string>;
    get formWakeTime() {
        return this.__formWakeTime.get();
    }
    set formWakeTime(newValue: string) {
        this.__formWakeTime.set(newValue);
    }
    private __formSleepQualityIndex: ObservedPropertySimplePU<number>;
    get formSleepQualityIndex() {
        return this.__formSleepQualityIndex.get();
    }
    set formSleepQualityIndex(newValue: number) {
        this.__formSleepQualityIndex.set(newValue);
    }
    private exerciseOptions: SelectOption[];
    private mealOptions: SelectOption[];
    private qualityOptions: SelectOption[];
    aboutToAppear(): void {
        const params = this.pathStack.getParamByName(PageName.RECORD) as RecordPageParams | undefined;
        if (params !== undefined && params.recordType !== undefined) {
            this.currentType = params.recordType;
            Logger.info(Constants.TAG_RECORD, 'open with recordType=' + this.currentType.toString());
        }
        else {
            Logger.warn(Constants.TAG_RECORD, 'no recordType param, use default');
        }
        this.loadAll();
    }
    // ===== 数据加载 =====
    private async loadAll(): Promise<void> {
        this.loading = true;
        this.loadError = false;
        try {
            const service = HealthDataService.getInstance();
            this.exerciseList = await service.listExercise();
            this.dietList = await service.listDiet();
            this.sleepList = await service.listSleep();
            Logger.info(Constants.TAG_RECORD, 'load all records ok');
        }
        catch (e) {
            this.loadError = true;
            this.exerciseList = [];
            this.dietList = [];
            this.sleepList = [];
            Logger.error(Constants.TAG_RECORD, 'load all records failed');
        }
        finally {
            this.loading = false;
        }
    }
    // ===== 交互 =====
    private switchType(type: RecordType): void {
        if (this.currentType === type) {
            return;
        }
        this.currentType = type;
        this.editing = false;
    }
    private startAdd(): void {
        this.editingId = '';
        this.formDate = DateUtil.today();
        this.formNote = '';
        this.formExerciseTypeIndex = 0;
        this.formDuration = '';
        this.formCalories = '';
        this.formDistance = '';
        this.formMealTypeIndex = 0;
        this.formFoodName = '';
        this.formDietCalories = '';
        this.formBedTime = '23:00';
        this.formWakeTime = '07:00';
        this.formSleepQualityIndex = 0;
        this.editing = true;
    }
    private startEditById(id: string): void {
        this.editingId = id;
        this.formNote = '';
        if (this.currentType === RecordType.EXERCISE) {
            const found = this.exerciseList.find((item: ExerciseRecord) => item.id === id);
            if (found !== undefined) {
                this.formDate = found.date;
                this.formNote = found.note;
                this.formExerciseTypeIndex = this.indexOfValue(this.exerciseOptions, found.type);
                this.formDuration = found.durationMinutes.toString();
                this.formCalories = found.calories.toString();
                this.formDistance = found.distanceKm.toString();
            }
        }
        else if (this.currentType === RecordType.DIET) {
            const found = this.dietList.find((item: DietRecord) => item.id === id);
            if (found !== undefined) {
                this.formDate = found.date;
                this.formNote = found.note;
                this.formMealTypeIndex = this.indexOfValue(this.mealOptions, found.mealType);
                this.formFoodName = found.foodName;
                this.formDietCalories = found.calories.toString();
            }
        }
        else {
            const found = this.sleepList.find((item: SleepRecord) => item.id === id);
            if (found !== undefined) {
                this.formDate = found.date;
                this.formNote = found.note;
                this.formBedTime = found.bedTime;
                this.formWakeTime = found.wakeTime;
                this.formSleepQualityIndex = this.indexOfValue(this.qualityOptions, found.quality);
            }
        }
        this.editing = true;
    }
    private indexOfValue(options: SelectOption[], value: string): number {
        for (let i = 0; i < options.length; i++) {
            const v: string = options[i].value as string;
            if (v === value) {
                return i;
            }
        }
        return 0;
    }
    private cancelEdit(): void {
        this.editing = false;
    }
    private showToast(message: string): void {
        promptAction.showToast({ message: message, duration: 2000 });
    }
    private validateForm(): string {
        if (this.formDate.trim() === '') {
            return '请填写日期';
        }
        if (this.currentType === RecordType.EXERCISE) {
            const duration = Number(this.formDuration.trim());
            if (this.formDuration.trim() === '' || isNaN(duration) || duration <= 0) {
                return '请填写有效的运动时长（分钟）';
            }
            const calories = Number(this.formCalories.trim());
            if (this.formCalories.trim() === '' || isNaN(calories) || calories < 0) {
                return '请填写有效的消耗热量（千卡）';
            }
            const distance = Number(this.formDistance.trim());
            if (this.formDistance.trim() === '' || isNaN(distance) || distance < 0) {
                return '请填写有效的距离（公里）';
            }
        }
        else if (this.currentType === RecordType.DIET) {
            if (this.formFoodName.trim() === '') {
                return '请填写食物名称';
            }
            const calories = Number(this.formDietCalories.trim());
            if (this.formDietCalories.trim() === '' || isNaN(calories) || calories <= 0) {
                return '请填写有效的热量（千卡）';
            }
        }
        else {
            if (this.formBedTime.trim() === '' || this.formWakeTime.trim() === '') {
                return '请填写入睡与起床时间';
            }
            if (this.formBedTime.trim() === this.formWakeTime.trim()) {
                return '入睡与起床时间不能相同';
            }
        }
        return '';
    }
    private async save(): Promise<void> {
        const err = this.validateForm();
        if (err !== '') {
            this.showToast(err);
            return;
        }
        try {
            const service = HealthDataService.getInstance();
            if (this.currentType === RecordType.EXERCISE) {
                const record: ExerciseRecord = {
                    id: this.editingId === '' ? DateUtil.genId('ex') : this.editingId,
                    date: this.formDate.trim(),
                    type: this.exerciseOptions[this.formExerciseTypeIndex].value as string,
                    durationMinutes: Number(this.formDuration.trim()),
                    calories: Number(this.formCalories.trim()),
                    distanceKm: Number(this.formDistance.trim()),
                    note: this.formNote.trim()
                };
                if (this.editingId === '') {
                    await service.addExercise(record);
                }
                else {
                    await service.updateExercise(record);
                }
            }
            else if (this.currentType === RecordType.DIET) {
                const record: DietRecord = {
                    id: this.editingId === '' ? DateUtil.genId('diet') : this.editingId,
                    date: this.formDate.trim(),
                    mealType: this.mealOptions[this.formMealTypeIndex].value as string,
                    foodName: this.formFoodName.trim(),
                    calories: Number(this.formDietCalories.trim()),
                    note: this.formNote.trim()
                };
                if (this.editingId === '') {
                    await service.addDiet(record);
                }
                else {
                    await service.updateDiet(record);
                }
            }
            else {
                const record: SleepRecord = {
                    id: this.editingId === '' ? DateUtil.genId('sleep') : this.editingId,
                    date: this.formDate.trim(),
                    bedTime: this.formBedTime.trim(),
                    wakeTime: this.formWakeTime.trim(),
                    sleepHours: DateUtil.sleepHours(this.formBedTime.trim(), this.formWakeTime.trim()),
                    quality: this.qualityOptions[this.formSleepQualityIndex].value as string,
                    note: this.formNote.trim()
                };
                if (this.editingId === '') {
                    await service.addSleep(record);
                }
                else {
                    await service.updateSleep(record);
                }
            }
            this.showToast('保存成功');
            this.editing = false;
            await this.loadAll();
            DataEvents.bump();
        }
        catch (e) {
            Logger.error(Constants.TAG_RECORD, 'save record failed');
            this.showToast('保存失败，请重试');
        }
    }
    private confirmDelete(id: string): void {
        AlertDialog.show({
            title: '删除确认',
            message: '确定删除这条记录吗？删除后不可恢复。',
            autoCancel: true,
            alignment: DialogAlignment.Center,
            primaryButton: {
                value: '删除',
                fontColor: '#E84026',
                action: () => {
                    this.doDelete(id);
                }
            },
            secondaryButton: {
                value: '取消',
                fontColor: '#666666',
                action: () => {
                }
            }
        });
    }
    private async doDelete(id: string): Promise<void> {
        try {
            const service = HealthDataService.getInstance();
            if (this.currentType === RecordType.EXERCISE) {
                await service.deleteExercise(id);
            }
            else if (this.currentType === RecordType.DIET) {
                await service.deleteDiet(id);
            }
            else {
                await service.deleteSleep(id);
            }
            this.showToast('删除成功');
            await this.loadAll();
            DataEvents.bump();
        }
        catch (e) {
            Logger.error(Constants.TAG_RECORD, 'delete record failed');
            this.showToast('删除失败，请重试');
        }
    }
    // ===== 视图辅助 =====
    private tabColor(type: RecordType): ResourceColor {
        if (type === this.currentType) {
            return '#1677FF';
        }
        return '#666666';
    }
    private tabBg(type: RecordType): ResourceColor {
        if (type === this.currentType) {
            return '#E8F1FF';
        }
        return '#FFFFFF';
    }
    private tabWeight(type: RecordType): FontWeight {
        if (type === this.currentType) {
            return FontWeight.Bold;
        }
        return FontWeight.Normal;
    }
    private formTitle(): string {
        if (this.editingId === '') {
            return '新增记录';
        }
        return '编辑记录';
    }
    private computedSleepHours(): number {
        return DateUtil.sleepHours(this.formBedTime.trim(), this.formWakeTime.trim());
    }
    // ===== UI Builder =====
    TabItem(label: string, type: RecordType, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/RecordPage.ets(348:5)", "entry");
            Text.fontSize(14);
            Text.fontWeight(this.tabWeight(type));
            Text.fontColor(this.tabColor(type));
            Text.backgroundColor(this.tabBg(type));
            Text.textAlign(TextAlign.Center);
            Text.layoutWeight(1);
            Text.padding({ top: 8, bottom: 8 });
            Text.borderRadius(8);
            Text.onClick(() => {
                this.switchType(type);
            });
        }, Text);
        Text.pop();
    }
    TypeTabs(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RecordPage.ets(364:5)", "entry");
            Row.width('100%');
            Row.padding(4);
            Row.borderRadius(12);
            Row.backgroundColor('#FFFFFF');
        }, Row);
        this.TabItem.bind(this)('运动', RecordType.EXERCISE);
        this.TabItem.bind(this)('饮食', RecordType.DIET);
        this.TabItem.bind(this)('睡眠', RecordType.SLEEP);
        Row.pop();
    }
    FieldLabel(text: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(text);
            Text.debugLine("entry/src/main/ets/pages/RecordPage.ets(377:5)", "entry");
            Text.fontSize(13);
            Text.fontColor('#666666');
            Text.width('100%');
            Text.margin({ top: 12, bottom: 6 });
        }, Text);
        Text.pop();
    }
    FormFields(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentType === RecordType.EXERCISE) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.FieldLabel.bind(this)('运动类型');
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Select.create(this.exerciseOptions);
                        Select.debugLine("entry/src/main/ets/pages/RecordPage.ets(388:7)", "entry");
                        Select.selected(this.formExerciseTypeIndex);
                        Select.value(this.exerciseOptions[this.formExerciseTypeIndex].value);
                        Select.onSelect((index: number) => {
                            this.formExerciseTypeIndex = index;
                        });
                        Select.width('100%');
                    }, Select);
                    Select.pop();
                    this.FieldLabel.bind(this)('时长（分钟）');
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '例如 30', text: { value: this.formDuration, changeEvent: newValue => { this.formDuration = newValue; } } });
                        TextInput.debugLine("entry/src/main/ets/pages/RecordPage.ets(397:7)", "entry");
                        TextInput.width('100%');
                    }, TextInput);
                    this.FieldLabel.bind(this)('消耗热量（千卡）');
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '例如 200', text: { value: this.formCalories, changeEvent: newValue => { this.formCalories = newValue; } } });
                        TextInput.debugLine("entry/src/main/ets/pages/RecordPage.ets(401:7)", "entry");
                        TextInput.width('100%');
                    }, TextInput);
                    this.FieldLabel.bind(this)('距离（公里）');
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '例如 3.2', text: { value: this.formDistance, changeEvent: newValue => { this.formDistance = newValue; } } });
                        TextInput.debugLine("entry/src/main/ets/pages/RecordPage.ets(405:7)", "entry");
                        TextInput.width('100%');
                    }, TextInput);
                });
            }
            else if (this.currentType === RecordType.DIET) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.FieldLabel.bind(this)('餐次');
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Select.create(this.mealOptions);
                        Select.debugLine("entry/src/main/ets/pages/RecordPage.ets(409:7)", "entry");
                        Select.selected(this.formMealTypeIndex);
                        Select.value(this.mealOptions[this.formMealTypeIndex].value);
                        Select.onSelect((index: number) => {
                            this.formMealTypeIndex = index;
                        });
                        Select.width('100%');
                    }, Select);
                    Select.pop();
                    this.FieldLabel.bind(this)('食物名称');
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '例如 燕麦牛奶', text: { value: this.formFoodName, changeEvent: newValue => { this.formFoodName = newValue; } } });
                        TextInput.debugLine("entry/src/main/ets/pages/RecordPage.ets(418:7)", "entry");
                        TextInput.width('100%');
                    }, TextInput);
                    this.FieldLabel.bind(this)('热量（千卡）');
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '例如 320', text: { value: this.formDietCalories, changeEvent: newValue => { this.formDietCalories = newValue; } } });
                        TextInput.debugLine("entry/src/main/ets/pages/RecordPage.ets(422:7)", "entry");
                        TextInput.width('100%');
                    }, TextInput);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.FieldLabel.bind(this)('入睡时间（HH:mm）');
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '例如 23:30', text: { value: this.formBedTime, changeEvent: newValue => { this.formBedTime = newValue; } } });
                        TextInput.debugLine("entry/src/main/ets/pages/RecordPage.ets(426:7)", "entry");
                        TextInput.width('100%');
                    }, TextInput);
                    this.FieldLabel.bind(this)('起床时间（HH:mm）');
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '例如 07:00', text: { value: this.formWakeTime, changeEvent: newValue => { this.formWakeTime = newValue; } } });
                        TextInput.debugLine("entry/src/main/ets/pages/RecordPage.ets(430:7)", "entry");
                        TextInput.width('100%');
                    }, TextInput);
                    this.FieldLabel.bind(this)('睡眠质量');
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Select.create(this.qualityOptions);
                        Select.debugLine("entry/src/main/ets/pages/RecordPage.ets(434:7)", "entry");
                        Select.selected(this.formSleepQualityIndex);
                        Select.value(this.qualityOptions[this.formSleepQualityIndex].value);
                        Select.onSelect((index: number) => {
                            this.formSleepQualityIndex = index;
                        });
                        Select.width('100%');
                    }, Select);
                    Select.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('预计睡眠时长：' + this.computedSleepHours().toString() + ' 小时');
                        Text.debugLine("entry/src/main/ets/pages/RecordPage.ets(442:7)", "entry");
                        Text.fontSize(13);
                        Text.fontColor('#1677FF');
                        Text.width('100%');
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
    }
    EditForm(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/RecordPage.ets(452:5)", "entry");
            Scroll.width('100%');
            Scroll.layoutWeight(1);
            Scroll.backgroundColor('#F5F6F7');
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RecordPage.ets(453:7)", "entry");
            Column.width('100%');
            Column.padding(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RecordPage.ets(454:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.formTitle());
            Text.debugLine("entry/src/main/ets/pages/RecordPage.ets(455:11)", "entry");
            Text.fontSize(17);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#333333');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/RecordPage.ets(459:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('取消');
            Text.debugLine("entry/src/main/ets/pages/RecordPage.ets(460:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#1677FF');
            Text.onClick(() => {
                this.cancelEdit();
            });
        }, Text);
        Text.pop();
        Row.pop();
        this.FieldLabel.bind(this)('日期（yyyy-MM-dd）');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '例如 2026-11-23', text: { value: this.formDate, changeEvent: newValue => { this.formDate = newValue; } } });
            TextInput.debugLine("entry/src/main/ets/pages/RecordPage.ets(470:9)", "entry");
            TextInput.width('100%');
        }, TextInput);
        this.FormFields.bind(this)();
        this.FieldLabel.bind(this)('备注（可选）');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextArea.create({ placeholder: '补充说明（可选）', text: { value: this.formNote, changeEvent: newValue => { this.formNote = newValue; } } });
            TextArea.debugLine("entry/src/main/ets/pages/RecordPage.ets(476:9)", "entry");
            TextArea.width('100%');
            TextArea.height(80);
        }, TextArea);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('保存');
            Button.debugLine("entry/src/main/ets/pages/RecordPage.ets(480:9)", "entry");
            Button.width('100%');
            Button.margin({ top: 20 });
            Button.onClick(() => {
                this.save();
            });
        }, Button);
        Button.pop();
        Column.pop();
        Scroll.pop();
    }
    EmptyState(text: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/RecordPage.ets(497:5)", "entry");
            Column.width('100%');
            Column.padding(30);
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(text);
            Text.debugLine("entry/src/main/ets/pages/RecordPage.ets(498:7)", "entry");
            Text.fontSize(14);
            Text.fontColor('#999999');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('立即新增');
            Button.debugLine("entry/src/main/ets/pages/RecordPage.ets(501:7)", "entry");
            Button.fontSize(13);
            Button.onClick(() => {
                this.startAdd();
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    RecordListItem(title: string, subtitle: string, note: string, id: string, parent = null) {
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, true);
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/RecordPage.ets(514:5)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/RecordPage.ets(515:7)", "entry");
                    Row.width('100%');
                    Row.padding(14);
                    Row.borderRadius(12);
                    Row.backgroundColor('#FFFFFF');
                    Row.alignItems(VerticalAlign.Center);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 4 });
                    Column.debugLine("entry/src/main/ets/pages/RecordPage.ets(516:9)", "entry");
                    Column.alignItems(HorizontalAlign.Start);
                    Column.layoutWeight(1);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(title);
                    Text.debugLine("entry/src/main/ets/pages/RecordPage.ets(517:11)", "entry");
                    Text.fontSize(16);
                    Text.fontWeight(FontWeight.Medium);
                    Text.fontColor('#333333');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(subtitle);
                    Text.debugLine("entry/src/main/ets/pages/RecordPage.ets(521:11)", "entry");
                    Text.fontSize(13);
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (note !== '') {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('备注：' + note);
                                Text.debugLine("entry/src/main/ets/pages/RecordPage.ets(525:13)", "entry");
                                Text.fontSize(12);
                                Text.fontColor('#999999');
                            }, Text);
                            Text.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(1, () => {
                        });
                    }
                }, If);
                If.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 8 });
                    Column.debugLine("entry/src/main/ets/pages/RecordPage.ets(533:9)", "entry");
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('编辑');
                    Button.debugLine("entry/src/main/ets/pages/RecordPage.ets(534:11)", "entry");
                    Button.fontSize(12);
                    Button.height(28);
                    Button.onClick(() => {
                        this.startEditById(id);
                    });
                }, Button);
                Button.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('删除');
                    Button.debugLine("entry/src/main/ets/pages/RecordPage.ets(540:11)", "entry");
                    Button.fontSize(12);
                    Button.height(28);
                    Button.backgroundColor('#FDE8E8');
                    Button.fontColor('#E84026');
                    Button.onClick(() => {
                        this.confirmDelete(id);
                    });
                }, Button);
                Button.pop();
                Column.pop();
                Row.pop();
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            ListItem.pop();
        }
    }
    ListContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/RecordPage.ets(560:5)", "entry");
            Column.width('100%');
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('+ 新增记录');
            Button.debugLine("entry/src/main/ets/pages/RecordPage.ets(561:7)", "entry");
            Button.width('100%');
            Button.onClick(() => {
                this.startAdd();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentType === RecordType.EXERCISE) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.exerciseList.length === 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.EmptyState.bind(this)('暂无运动记录');
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    List.create({ space: 10 });
                                    List.debugLine("entry/src/main/ets/pages/RecordPage.ets(571:11)", "entry");
                                    List.width('100%');
                                    List.layoutWeight(1);
                                    List.scrollBar(BarState.Off);
                                }, List);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const item = _item;
                                        this.RecordListItem.bind(this)(item.type, item.durationMinutes.toString() + ' 分钟 · 消耗 ' + item.calories.toString() +
                                            ' 千卡 · ' + item.distanceKm.toString() + ' 公里', item.note, item.id);
                                    };
                                    this.forEachUpdateFunction(elmtId, this.exerciseList, forEachItemGenFunction, (item: ExerciseRecord) => item.id, false, false);
                                }, ForEach);
                                ForEach.pop();
                                List.pop();
                            });
                        }
                    }, If);
                    If.pop();
                });
            }
            else if (this.currentType === RecordType.DIET) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.dietList.length === 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.EmptyState.bind(this)('暂无饮食记录');
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    List.create({ space: 10 });
                                    List.debugLine("entry/src/main/ets/pages/RecordPage.ets(590:11)", "entry");
                                    List.width('100%');
                                    List.layoutWeight(1);
                                    List.scrollBar(BarState.Off);
                                }, List);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const item = _item;
                                        this.RecordListItem.bind(this)(item.mealType + ' · ' + item.foodName, item.calories.toString() + ' 千卡 · ' + item.date, item.note, item.id);
                                    };
                                    this.forEachUpdateFunction(elmtId, this.dietList, forEachItemGenFunction, (item: DietRecord) => item.id, false, false);
                                }, ForEach);
                                ForEach.pop();
                                List.pop();
                            });
                        }
                    }, If);
                    If.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.sleepList.length === 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.EmptyState.bind(this)('暂无睡眠记录');
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    List.create({ space: 10 });
                                    List.debugLine("entry/src/main/ets/pages/RecordPage.ets(608:11)", "entry");
                                    List.width('100%');
                                    List.layoutWeight(1);
                                    List.scrollBar(BarState.Off);
                                }, List);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const item = _item;
                                        this.RecordListItem.bind(this)(item.quality + ' · ' + item.sleepHours.toString() + ' 小时', item.bedTime + ' 入睡 · ' + item.wakeTime + ' 起床 · ' + item.date, item.note, item.id);
                                    };
                                    this.forEachUpdateFunction(elmtId, this.sleepList, forEachItemGenFunction, (item: SleepRecord) => item.id, false, false);
                                }, ForEach);
                                ForEach.pop();
                                List.pop();
                            });
                        }
                    }, If);
                    If.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            NavDestination.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 10 });
                    Column.debugLine("entry/src/main/ets/pages/RecordPage.ets(630:7)", "entry");
                    Column.width('100%');
                    Column.height('100%');
                    Column.padding(12);
                    Column.backgroundColor('#F5F6F7');
                }, Column);
                this.TypeTabs.bind(this)();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (this.editing) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.EditForm.bind(this)();
                        });
                    }
                    else if (this.loading) {
                        this.ifElseBranchUpdateFunction(1, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create({ space: 10 });
                                Column.debugLine("entry/src/main/ets/pages/RecordPage.ets(635:11)", "entry");
                                Column.width('100%');
                                Column.layoutWeight(1);
                                Column.justifyContent(FlexAlign.Center);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                LoadingProgress.create();
                                LoadingProgress.debugLine("entry/src/main/ets/pages/RecordPage.ets(636:13)", "entry");
                                LoadingProgress.width(40);
                                LoadingProgress.height(40);
                                LoadingProgress.color('#1677FF');
                            }, LoadingProgress);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('加载中…');
                                Text.debugLine("entry/src/main/ets/pages/RecordPage.ets(640:13)", "entry");
                                Text.fontSize(13);
                                Text.fontColor('#999999');
                            }, Text);
                            Text.pop();
                            Column.pop();
                        });
                    }
                    else if (this.loadError) {
                        this.ifElseBranchUpdateFunction(2, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create({ space: 10 });
                                Column.debugLine("entry/src/main/ets/pages/RecordPage.ets(648:11)", "entry");
                                Column.width('100%');
                                Column.layoutWeight(1);
                                Column.justifyContent(FlexAlign.Center);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('数据加载失败');
                                Text.debugLine("entry/src/main/ets/pages/RecordPage.ets(649:13)", "entry");
                                Text.fontSize(14);
                                Text.fontColor('#666666');
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Button.createWithLabel('重试');
                                Button.debugLine("entry/src/main/ets/pages/RecordPage.ets(652:13)", "entry");
                                Button.fontSize(13);
                                Button.onClick(() => {
                                    this.loadAll();
                                });
                            }, Button);
                            Button.pop();
                            Column.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(3, () => {
                            this.ListContent.bind(this)();
                        });
                    }
                }, If);
                If.pop();
                Column.pop();
            }, { moduleName: "entry", pagePath: "entry/src/main/ets/pages/RecordPage" });
            NavDestination.title('健康记录');
            NavDestination.onBackPressed(() => {
                this.pathStack.pop();
                Logger.info(Constants.TAG_RECORD, 'back to dashboard');
                return true;
            });
            NavDestination.debugLine("entry/src/main/ets/pages/RecordPage.ets(629:5)", "entry");
        }, NavDestination);
        NavDestination.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public __resetStateVarsOnReuse__Internal(params: Object): void {
        this.__reInitializeConsume__Internal('pathStack', "pathStack");
    }
}
