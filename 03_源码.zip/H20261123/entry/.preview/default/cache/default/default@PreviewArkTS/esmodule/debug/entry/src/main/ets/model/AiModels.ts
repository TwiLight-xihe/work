/**
 * 云端 AI 相关数据结构定义（model 层）。
 */
/** 对话消息（OpenAI 兼容格式） */
export interface ChatMessage {
    role: string; // system | user | assistant
    content: string;
}
/** 单条候选结果 */
export interface ChatChoice {
    message: ChatMessage;
}
/** chat/completions 响应体（仅声明需要解析的字段） */
export interface ChatCompletionResponse {
    choices: ChatChoice[];
}
/** chat/completions 请求体 */
export interface ChatRequestBody {
    model: string;
    messages: ChatMessage[];
    stream: boolean;
}
/**
 * 自定义 AI 错误：携带错误码 + 友好提示。
 * code 含义：-1 网络/超时；-2 JSON 解析异常；>=400 HTTP 状态码。
 */
export class AiServiceError extends Error {
    code: number = 0;
    constructor(code: number, message: string) {
        super(message);
        this.code = code;
    }
}
