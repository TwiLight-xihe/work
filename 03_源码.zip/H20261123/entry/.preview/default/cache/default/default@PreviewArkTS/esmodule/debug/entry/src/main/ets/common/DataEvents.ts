/**
 * 跨页面数据变更通知（common 层）。
 * 通过 AppStorage 维护一个递增版本号；页面用 @StorageLink + @Watch 监听，
 * 数据变化后自动触发刷新（解决「返回首页后概览不刷新」问题）。
 */
export class DataEvents {
    static readonly KEY: string = 'healthDataVersion';
    /** 记录增删改后调用，通知所有监听页面刷新 */
    static bump(): void {
        const cur: number | undefined = AppStorage.get<number>(DataEvents.KEY);
        const next: number = (cur === undefined ? 0 : cur) + 1;
        AppStorage.setOrCreate<number>(DataEvents.KEY, next);
    }
}
