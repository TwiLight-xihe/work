import type { ExerciseRecord, DietRecord, SleepRecord, HealthAdvice } from '../model/HealthModels';
import { StorageService } from "@normalized:N&&&entry/src/main/ets/service/StorageService&";
import { StorageConfig } from "@normalized:N&&&entry/src/main/ets/common/Config&";
import { DateUtil } from "@normalized:N&&&entry/src/main/ets/common/DateUtil&";
import { Logger } from "@normalized:N&&&entry/src/main/ets/common/Logger&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
/**
 * 持久化仓库层（service 层）。
 * 使用 Preferences 保存 JSON 序列化后的记录与建议，实现「退出/重启后数据不丢失」。
 * 每个读取方法都做了异常数据兜底：解析失败时返回空数组，保证不崩溃。
 */
export class HealthRepository {
    private static instance: HealthRepository | null = null;
    private seeded: boolean = false;
    static getInstance(): HealthRepository {
        if (HealthRepository.instance === null) {
            HealthRepository.instance = new HealthRepository();
        }
        return HealthRepository.instance;
    }
    private constructor() {
    }
    /** 首次启动预置演示数据（仅执行一次，删除后不会重复预置） */
    private async ensureSeeded(): Promise<void> {
        if (this.seeded) {
            return;
        }
        const seeded = await StorageService.getBoolean(StorageConfig.KEY_SEEDED, false);
        if (seeded) {
            this.seeded = true;
            return;
        }
        const today: string = DateUtil.today();
        const exercise: ExerciseRecord = {
            id: DateUtil.genId('ex'),
            date: today,
            type: '跑步',
            durationMinutes: 25,
            calories: 180,
            distanceKm: 3.2,
            note: '晨跑'
        };
        const diet: DietRecord = {
            id: DateUtil.genId('diet'),
            date: today,
            mealType: '早餐',
            foodName: '燕麦牛奶',
            calories: 320,
            note: ''
        };
        const sleep: SleepRecord = {
            id: DateUtil.genId('sleep'),
            date: today,
            bedTime: '23:30',
            wakeTime: '07:00',
            sleepHours: 7.5,
            quality: '良好',
            note: ''
        };
        await this.saveExerciseList([exercise]);
        await this.saveDietList([diet]);
        await this.saveSleepList([sleep]);
        await StorageService.putBoolean(StorageConfig.KEY_SEEDED, true);
        this.seeded = true;
        Logger.info(Constants.TAG_SERVICE, 'seed demo data ok');
    }
    // ===== 运动记录 =====
    async listExercise(): Promise<ExerciseRecord[]> {
        await this.ensureSeeded();
        const raw = await StorageService.getString(StorageConfig.KEY_EXERCISE, '[]');
        return this.parseExerciseList(raw);
    }
    async addExercise(record: ExerciseRecord): Promise<void> {
        await this.ensureSeeded();
        const list = await this.listExercise();
        await this.saveExerciseList([record, ...list]);
    }
    async updateExercise(record: ExerciseRecord): Promise<void> {
        const list = await this.listExercise();
        const idx = list.findIndex((item: ExerciseRecord) => item.id === record.id);
        if (idx >= 0) {
            list[idx] = record;
            await this.saveExerciseList(list);
        }
    }
    async deleteExercise(id: string): Promise<void> {
        const list = await this.listExercise();
        await this.saveExerciseList(list.filter((item: ExerciseRecord) => item.id !== id));
    }
    private async saveExerciseList(list: ExerciseRecord[]): Promise<void> {
        await StorageService.putString(StorageConfig.KEY_EXERCISE, JSON.stringify(list));
    }
    private parseExerciseList(raw: string): ExerciseRecord[] {
        if (raw === '' || raw === 'null') {
            return [];
        }
        try {
            const list = JSON.parse(raw) as ExerciseRecord[];
            if (list === null || list === undefined) {
                return [];
            }
            return list;
        }
        catch (e) {
            Logger.warn(Constants.TAG_SERVICE, 'parse exercise list failed, reset empty');
            return [];
        }
    }
    // ===== 饮食记录 =====
    async listDiet(): Promise<DietRecord[]> {
        await this.ensureSeeded();
        const raw = await StorageService.getString(StorageConfig.KEY_DIET, '[]');
        return this.parseDietList(raw);
    }
    async addDiet(record: DietRecord): Promise<void> {
        await this.ensureSeeded();
        const list = await this.listDiet();
        await this.saveDietList([record, ...list]);
    }
    async updateDiet(record: DietRecord): Promise<void> {
        const list = await this.listDiet();
        const idx = list.findIndex((item: DietRecord) => item.id === record.id);
        if (idx >= 0) {
            list[idx] = record;
            await this.saveDietList(list);
        }
    }
    async deleteDiet(id: string): Promise<void> {
        const list = await this.listDiet();
        await this.saveDietList(list.filter((item: DietRecord) => item.id !== id));
    }
    private async saveDietList(list: DietRecord[]): Promise<void> {
        await StorageService.putString(StorageConfig.KEY_DIET, JSON.stringify(list));
    }
    private parseDietList(raw: string): DietRecord[] {
        if (raw === '' || raw === 'null') {
            return [];
        }
        try {
            const list = JSON.parse(raw) as DietRecord[];
            if (list === null || list === undefined) {
                return [];
            }
            return list;
        }
        catch (e) {
            Logger.warn(Constants.TAG_SERVICE, 'parse diet list failed, reset empty');
            return [];
        }
    }
    // ===== 睡眠记录 =====
    async listSleep(): Promise<SleepRecord[]> {
        await this.ensureSeeded();
        const raw = await StorageService.getString(StorageConfig.KEY_SLEEP, '[]');
        return this.parseSleepList(raw);
    }
    async addSleep(record: SleepRecord): Promise<void> {
        await this.ensureSeeded();
        const list = await this.listSleep();
        await this.saveSleepList([record, ...list]);
    }
    async updateSleep(record: SleepRecord): Promise<void> {
        const list = await this.listSleep();
        const idx = list.findIndex((item: SleepRecord) => item.id === record.id);
        if (idx >= 0) {
            list[idx] = record;
            await this.saveSleepList(list);
        }
    }
    async deleteSleep(id: string): Promise<void> {
        const list = await this.listSleep();
        await this.saveSleepList(list.filter((item: SleepRecord) => item.id !== id));
    }
    private async saveSleepList(list: SleepRecord[]): Promise<void> {
        await StorageService.putString(StorageConfig.KEY_SLEEP, JSON.stringify(list));
    }
    private parseSleepList(raw: string): SleepRecord[] {
        if (raw === '' || raw === 'null') {
            return [];
        }
        try {
            const list = JSON.parse(raw) as SleepRecord[];
            if (list === null || list === undefined) {
                return [];
            }
            return list;
        }
        catch (e) {
            Logger.warn(Constants.TAG_SERVICE, 'parse sleep list failed, reset empty');
            return [];
        }
    }
    // ===== 建议历史 =====
    async listAdvice(): Promise<HealthAdvice[]> {
        const raw = await StorageService.getString(StorageConfig.KEY_ADVICE, '[]');
        return this.parseAdviceList(raw);
    }
    async addAdvice(advice: HealthAdvice): Promise<void> {
        const list = await this.listAdvice();
        await this.saveAdviceList([advice, ...list]);
    }
    async clearAdvice(): Promise<void> {
        await StorageService.remove(StorageConfig.KEY_ADVICE);
    }
    private async saveAdviceList(list: HealthAdvice[]): Promise<void> {
        await StorageService.putString(StorageConfig.KEY_ADVICE, JSON.stringify(list));
    }
    private parseAdviceList(raw: string): HealthAdvice[] {
        if (raw === '' || raw === 'null') {
            return [];
        }
        try {
            const list = JSON.parse(raw) as HealthAdvice[];
            if (list === null || list === undefined) {
                return [];
            }
            return list;
        }
        catch (e) {
            Logger.warn(Constants.TAG_SERVICE, 'parse advice list failed, reset empty');
            return [];
        }
    }
}
