if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface AiAdvicePage_Params {
    pathStack?: NavPathStack;
    hasAdvice?: boolean;
    advice?: HealthAdvice;
    analyzing?: boolean;
    question?: string;
    history?: HealthAdvice[];
    historyLoading?: boolean;
    historyError?: boolean;
}
import promptAction from "@ohos:promptAction";
import type { HealthAdvice } from '../model/HealthModels';
import type { AiServiceError } from '../model/AiModels';
import { AiAdviceService } from "@normalized:N&&&entry/src/main/ets/service/AiAdviceService&";
import { AiConfig } from "@normalized:N&&&entry/src/main/ets/common/Config&";
import { Logger } from "@normalized:N&&&entry/src/main/ets/common/Logger&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
export class AiAdvicePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__pathStack = this.initializeConsume('pathStack', "pathStack");
        this.__hasAdvice = new ObservedPropertySimplePU(false, this, "hasAdvice");
        this.__advice = new ObservedPropertyObjectPU({
            id: '',
            createTime: '',
            sourceType: '',
            title: '',
            summary: '',
            suggestion: '',
            disclaimer: '',
            degraded: false
        }, this, "advice");
        this.__analyzing = new ObservedPropertySimplePU(false, this, "analyzing");
        this.__question = new ObservedPropertySimplePU('', this, "question");
        this.__history = new ObservedPropertyObjectPU([], this, "history");
        this.__historyLoading = new ObservedPropertySimplePU(false, this, "historyLoading");
        this.__historyError = new ObservedPropertySimplePU(false, this, "historyError");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: AiAdvicePage_Params) {
        if (params.hasAdvice !== undefined) {
            this.hasAdvice = params.hasAdvice;
        }
        if (params.advice !== undefined) {
            this.advice = params.advice;
        }
        if (params.analyzing !== undefined) {
            this.analyzing = params.analyzing;
        }
        if (params.question !== undefined) {
            this.question = params.question;
        }
        if (params.history !== undefined) {
            this.history = params.history;
        }
        if (params.historyLoading !== undefined) {
            this.historyLoading = params.historyLoading;
        }
        if (params.historyError !== undefined) {
            this.historyError = params.historyError;
        }
    }
    updateStateVars(params: AiAdvicePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__pathStack.purgeDependencyOnElmtId(rmElmtId);
        this.__hasAdvice.purgeDependencyOnElmtId(rmElmtId);
        this.__advice.purgeDependencyOnElmtId(rmElmtId);
        this.__analyzing.purgeDependencyOnElmtId(rmElmtId);
        this.__question.purgeDependencyOnElmtId(rmElmtId);
        this.__history.purgeDependencyOnElmtId(rmElmtId);
        this.__historyLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__historyError.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__pathStack.aboutToBeDeleted();
        this.__hasAdvice.aboutToBeDeleted();
        this.__advice.aboutToBeDeleted();
        this.__analyzing.aboutToBeDeleted();
        this.__question.aboutToBeDeleted();
        this.__history.aboutToBeDeleted();
        this.__historyLoading.aboutToBeDeleted();
        this.__historyError.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __pathStack: ObservedPropertyAbstractPU<NavPathStack>;
    get pathStack() {
        return this.__pathStack.get();
    }
    set pathStack(newValue: NavPathStack) {
        this.__pathStack.set(newValue);
    }
    private __hasAdvice: ObservedPropertySimplePU<boolean>;
    get hasAdvice() {
        return this.__hasAdvice.get();
    }
    set hasAdvice(newValue: boolean) {
        this.__hasAdvice.set(newValue);
    }
    private __advice: ObservedPropertyObjectPU<HealthAdvice>;
    get advice() {
        return this.__advice.get();
    }
    set advice(newValue: HealthAdvice) {
        this.__advice.set(newValue);
    }
    private __analyzing: ObservedPropertySimplePU<boolean>;
    get analyzing() {
        return this.__analyzing.get();
    }
    set analyzing(newValue: boolean) {
        this.__analyzing.set(newValue);
    }
    private __question: ObservedPropertySimplePU<string>;
    get question() {
        return this.__question.get();
    }
    set question(newValue: string) {
        this.__question.set(newValue);
    }
    private __history: ObservedPropertyObjectPU<HealthAdvice[]>;
    get history() {
        return this.__history.get();
    }
    set history(newValue: HealthAdvice[]) {
        this.__history.set(newValue);
    }
    private __historyLoading: ObservedPropertySimplePU<boolean>;
    get historyLoading() {
        return this.__historyLoading.get();
    }
    set historyLoading(newValue: boolean) {
        this.__historyLoading.set(newValue);
    }
    private __historyError: ObservedPropertySimplePU<boolean>;
    get historyError() {
        return this.__historyError.get();
    }
    set historyError(newValue: boolean) {
        this.__historyError.set(newValue);
    }
    aboutToAppear(): void {
        Logger.info(Constants.TAG_ADVICE, 'ai advice page open');
        this.loadHistory();
    }
    private async loadHistory(): Promise<void> {
        this.historyLoading = true;
        this.historyError = false;
        try {
            this.history = await AiAdviceService.getInstance().getHistory();
        }
        catch (e) {
            this.historyError = true;
            this.history = [];
            Logger.error(Constants.TAG_ADVICE, 'load history failed');
        }
        finally {
            this.historyLoading = false;
        }
    }
    private async runAnalysis(): Promise<void> {
        this.analyzing = true;
        try {
            this.advice = await AiAdviceService.getInstance().generateAnalysis();
            this.hasAdvice = true;
            Logger.info(Constants.TAG_ADVICE, 'analysis ok');
        }
        catch (e) {
            Logger.error(Constants.TAG_ADVICE, 'analysis failed');
            this.showToast('分析失败，请重试');
        }
        finally {
            this.analyzing = false;
        }
    }
    private async askQuestion(): Promise<void> {
        if (this.question.trim() === '') {
            this.showToast('请先输入问题');
            return;
        }
        this.analyzing = true;
        try {
            this.advice = await AiAdviceService.getInstance().askQuestion(this.question);
            this.hasAdvice = true;
        }
        catch (e) {
            this.showToast('问答失败，请重试');
        }
        finally {
            this.analyzing = false;
        }
    }
    private async saveCurrent(): Promise<void> {
        if (!this.hasAdvice) {
            return;
        }
        try {
            await AiAdviceService.getInstance().saveAdvice(this.advice);
            this.showToast('已保存到历史建议');
            await this.loadHistory();
        }
        catch (e) {
            this.showToast('保存失败，请重试');
        }
    }
    private viewHistoryItem(item: HealthAdvice): void {
        this.advice = item;
        this.hasAdvice = true;
    }
    private resetConversation(): void {
        AiAdviceService.getInstance().resetConversation();
        this.showToast('已重置对话上下文');
    }
    private modeText(): string {
        if (AiConfig.isApiKeyConfigured()) {
            return '当前：云端模式（' + AiConfig.MODEL + '）';
        }
        return '当前：本地降级模式（未配置 API Key，请到 common/Config.ets 填写）';
    }
    private async testConnection(): Promise<void> {
        this.analyzing = true;
        try {
            await AiAdviceService.getInstance().testConnection();
            this.showToast('云端连接成功');
        }
        catch (e) {
            const err = e as AiServiceError;
            let msg: string = '连接失败';
            if (err.message !== undefined && err.message !== '') {
                msg = err.message;
            }
            this.showToast(msg);
        }
        finally {
            this.analyzing = false;
        }
    }
    private confirmClearHistory(): void {
        AlertDialog.show({
            title: '清空历史',
            message: '确定清空全部历史建议吗？',
            autoCancel: true,
            alignment: DialogAlignment.Center,
            primaryButton: {
                value: '清空',
                fontColor: '#E84026',
                action: () => {
                    this.doClearHistory();
                }
            },
            secondaryButton: {
                value: '取消',
                fontColor: '#666666',
                action: () => {
                }
            }
        });
    }
    private async doClearHistory(): Promise<void> {
        try {
            await AiAdviceService.getInstance().clearHistory();
            this.history = [];
            this.showToast('已清空历史');
        }
        catch (e) {
            this.showToast('清空失败，请重试');
        }
    }
    private showToast(message: string): void {
        promptAction.showToast({ message: message, duration: 2000 });
    }
    AdviceCard(item: HealthAdvice, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(170:5)", "entry");
            Column.width('100%');
            Column.padding(14);
            Column.borderRadius(12);
            Column.backgroundColor('#FFFFFF');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(171:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(172:9)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#333333');
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('保存建议');
            Button.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(177:9)", "entry");
            Button.fontSize(12);
            Button.height(28);
            Button.onClick(() => {
                this.saveCurrent();
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.degraded) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('本地降级建议');
                        Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(187:9)", "entry");
                        Text.fontSize(11);
                        Text.fontColor('#B8860B');
                        Text.backgroundColor('#FFF4E5');
                        Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                        Text.borderRadius(4);
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.createTime);
            Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(195:7)", "entry");
            Text.fontSize(11);
            Text.fontColor('#999999');
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('【摘要】');
            Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(200:7)", "entry");
            Text.fontSize(13);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor('#666666');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.summary);
            Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(204:7)", "entry");
            Text.fontSize(13);
            Text.fontColor('#333333');
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('【建议】');
            Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(209:7)", "entry");
            Text.fontSize(13);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor('#666666');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.suggestion);
            Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(213:7)", "entry");
            Text.fontSize(13);
            Text.fontColor('#333333');
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.disclaimer);
            Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(218:7)", "entry");
            Text.fontSize(11);
            Text.fontColor('#AAAAAA');
            Text.width('100%');
        }, Text);
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            NavDestination.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Scroll.create();
                    Scroll.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(232:7)", "entry");
                    Scroll.width('100%');
                    Scroll.height('100%');
                    Scroll.backgroundColor('#F5F6F7');
                }, Scroll);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 14 });
                    Column.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(233:9)", "entry");
                    Column.width('100%');
                    Column.padding(16);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.modeText());
                    Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(234:11)", "entry");
                    Text.fontSize(12);
                    Text.fontColor('#666666');
                    Text.width('100%');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (this.hasAdvice) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.AdviceCard.bind(this)(ObservedObject.GetRawObject(this.advice));
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(1, () => {
                        });
                    }
                }, If);
                If.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('生成今日健康分析');
                    Button.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(243:11)", "entry");
                    Button.width('100%');
                    Button.onClick(() => {
                        this.runAnalysis();
                    });
                    Button.enabled(!this.analyzing);
                }, Button);
                Button.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('测试云端连接');
                    Button.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(250:11)", "entry");
                    Button.width('100%');
                    Button.onClick(() => {
                        this.testConnection();
                    });
                    Button.enabled(!this.analyzing);
                }, Button);
                Button.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(257:11)", "entry");
                    Row.width('100%');
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('智能问答');
                    Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(258:13)", "entry");
                    Text.fontSize(14);
                    Text.fontWeight(FontWeight.Bold);
                    Text.fontColor('#333333');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Blank.create();
                    Blank.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(262:13)", "entry");
                }, Blank);
                Blank.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('重置上下文');
                    Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(263:13)", "entry");
                    Text.fontSize(12);
                    Text.fontColor('#1677FF');
                    Text.onClick(() => {
                        this.resetConversation();
                    });
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    TextInput.create({ placeholder: '例如：怎样改善睡眠？', text: { value: this.question, changeEvent: newValue => { this.question = newValue; } } });
                    TextInput.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(272:11)", "entry");
                    TextInput.width('100%');
                }, TextInput);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('提问');
                    Button.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(275:11)", "entry");
                    Button.width('100%');
                    Button.onClick(() => {
                        this.askQuestion();
                    });
                    Button.enabled(!this.analyzing);
                }, Button);
                Button.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (this.analyzing) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create({ space: 8 });
                                Row.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(283:13)", "entry");
                                Row.width('100%');
                                Row.justifyContent(FlexAlign.Center);
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                LoadingProgress.create();
                                LoadingProgress.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(284:15)", "entry");
                                LoadingProgress.width(20);
                                LoadingProgress.height(20);
                                LoadingProgress.color('#1677FF');
                            }, LoadingProgress);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('正在分析，请稍候…');
                                Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(288:15)", "entry");
                                Text.fontSize(13);
                                Text.fontColor('#999999');
                            }, Text);
                            Text.pop();
                            Row.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(1, () => {
                        });
                    }
                }, If);
                If.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(296:11)", "entry");
                    Row.width('100%');
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('历史建议');
                    Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(297:13)", "entry");
                    Text.fontSize(15);
                    Text.fontWeight(FontWeight.Bold);
                    Text.fontColor('#333333');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Blank.create();
                    Blank.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(301:13)", "entry");
                }, Blank);
                Blank.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('清空');
                    Button.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(302:13)", "entry");
                    Button.fontSize(12);
                    Button.height(28);
                    Button.backgroundColor('#FDE8E8');
                    Button.fontColor('#E84026');
                    Button.onClick(() => {
                        this.confirmClearHistory();
                    });
                }, Button);
                Button.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (this.historyLoading) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(314:13)", "entry");
                                Column.width('100%');
                                Column.padding(16);
                                Column.justifyContent(FlexAlign.Center);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                LoadingProgress.create();
                                LoadingProgress.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(315:15)", "entry");
                                LoadingProgress.width(32);
                                LoadingProgress.height(32);
                                LoadingProgress.color('#1677FF');
                            }, LoadingProgress);
                            Column.pop();
                        });
                    }
                    else if (this.historyError) {
                        this.ifElseBranchUpdateFunction(1, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create({ space: 8 });
                                Column.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(324:13)", "entry");
                                Column.width('100%');
                                Column.padding(16);
                                Column.alignItems(HorizontalAlign.Center);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('历史加载失败');
                                Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(325:15)", "entry");
                                Text.fontSize(13);
                                Text.fontColor('#666666');
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Button.createWithLabel('重试');
                                Button.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(328:15)", "entry");
                                Button.fontSize(12);
                                Button.onClick(() => {
                                    this.loadHistory();
                                });
                            }, Button);
                            Button.pop();
                            Column.pop();
                        });
                    }
                    else if (this.history.length === 0) {
                        this.ifElseBranchUpdateFunction(2, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('暂无历史建议，生成分析后点击「保存建议」即可留存。');
                                Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(338:13)", "entry");
                                Text.fontSize(13);
                                Text.fontColor('#999999');
                                Text.width('100%');
                                Text.padding(16);
                            }, Text);
                            Text.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(3, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create({ space: 10 });
                                Column.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(344:13)", "entry");
                                Column.width('100%');
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                ForEach.create();
                                const forEachItemGenFunction = _item => {
                                    const item = _item;
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create({ space: 4 });
                                        Column.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(346:17)", "entry");
                                        Column.width('100%');
                                        Column.padding(12);
                                        Column.borderRadius(10);
                                        Column.backgroundColor('#FFFFFF');
                                        Column.alignItems(HorizontalAlign.Start);
                                        Column.onClick(() => {
                                            this.viewHistoryItem(item);
                                        });
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.title);
                                        Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(347:19)", "entry");
                                        Text.fontSize(14);
                                        Text.fontWeight(FontWeight.Medium);
                                        Text.fontColor('#333333');
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.summary);
                                        Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(351:19)", "entry");
                                        Text.fontSize(12);
                                        Text.fontColor('#999999');
                                        Text.maxLines(2);
                                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.createTime);
                                        Text.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(356:19)", "entry");
                                        Text.fontSize(11);
                                        Text.fontColor('#BBBBBB');
                                    }, Text);
                                    Text.pop();
                                    Column.pop();
                                };
                                this.forEachUpdateFunction(elmtId, this.history, forEachItemGenFunction, (item: HealthAdvice) => item.id, false, false);
                            }, ForEach);
                            ForEach.pop();
                            Column.pop();
                        });
                    }
                }, If);
                If.pop();
                Column.pop();
                Scroll.pop();
            }, { moduleName: "entry", pagePath: "entry/src/main/ets/pages/AiAdvicePage" });
            NavDestination.title('AI 分析与建议');
            NavDestination.onBackPressed(() => {
                this.pathStack.pop();
                return true;
            });
            NavDestination.debugLine("entry/src/main/ets/pages/AiAdvicePage.ets(231:5)", "entry");
        }, NavDestination);
        NavDestination.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public __resetStateVarsOnReuse__Internal(params: Object): void {
        this.__reInitializeConsume__Internal('pathStack', "pathStack");
    }
}
