import type common from "@ohos:app.ability.common";
/**
 * 全局上下文持有器（common 层）。
 * 在 EntryAbility.onCreate 中注入 UIAbilityContext，供持久化层读取。
 */
export class GlobalContext {
    private static ctx: common.UIAbilityContext | null = null;
    static setContext(context: common.UIAbilityContext): void {
        GlobalContext.ctx = context;
    }
    static getContext(): common.UIAbilityContext | null {
        return GlobalContext.ctx;
    }
}
