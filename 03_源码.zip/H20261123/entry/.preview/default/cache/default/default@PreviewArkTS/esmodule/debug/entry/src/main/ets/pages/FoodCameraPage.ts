if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FoodCameraPage_Params {
    pathStack?: NavPathStack;
    analyzing?: boolean;
    hasResult?: boolean;
    result?: FoodRecognitionResult;
    selectedUri?: string;
}
import promptAction from "@ohos:promptAction";
import photoAccessHelper from "@ohos:file.photoAccessHelper";
import type { BusinessError } from "@ohos:base";
import type { FoodRecognitionResult, HealthAdvice } from '../model/HealthModels';
import { AiAdviceService } from "@normalized:N&&&entry/src/main/ets/service/AiAdviceService&";
import { DateUtil } from "@normalized:N&&&entry/src/main/ets/common/DateUtil&";
import { Logger } from "@normalized:N&&&entry/src/main/ets/common/Logger&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
export class FoodCameraPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__pathStack = this.initializeConsume('pathStack', "pathStack");
        this.__analyzing = new ObservedPropertySimplePU(false, this, "analyzing");
        this.__hasResult = new ObservedPropertySimplePU(false, this, "hasResult");
        this.__result = new ObservedPropertyObjectPU({
            foodName: '',
            confidence: 0,
            estimatedCalories: 0,
            summary: '',
            suggestion: '',
            imageUri: '',
            degraded: false
        }, this, "result");
        this.__selectedUri = new ObservedPropertySimplePU('', this, "selectedUri");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FoodCameraPage_Params) {
        if (params.analyzing !== undefined) {
            this.analyzing = params.analyzing;
        }
        if (params.hasResult !== undefined) {
            this.hasResult = params.hasResult;
        }
        if (params.result !== undefined) {
            this.result = params.result;
        }
        if (params.selectedUri !== undefined) {
            this.selectedUri = params.selectedUri;
        }
    }
    updateStateVars(params: FoodCameraPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__pathStack.purgeDependencyOnElmtId(rmElmtId);
        this.__analyzing.purgeDependencyOnElmtId(rmElmtId);
        this.__hasResult.purgeDependencyOnElmtId(rmElmtId);
        this.__result.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedUri.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__pathStack.aboutToBeDeleted();
        this.__analyzing.aboutToBeDeleted();
        this.__hasResult.aboutToBeDeleted();
        this.__result.aboutToBeDeleted();
        this.__selectedUri.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __pathStack: ObservedPropertyAbstractPU<NavPathStack>;
    get pathStack() {
        return this.__pathStack.get();
    }
    set pathStack(newValue: NavPathStack) {
        this.__pathStack.set(newValue);
    }
    private __analyzing: ObservedPropertySimplePU<boolean>;
    get analyzing() {
        return this.__analyzing.get();
    }
    set analyzing(newValue: boolean) {
        this.__analyzing.set(newValue);
    }
    private __hasResult: ObservedPropertySimplePU<boolean>;
    get hasResult() {
        return this.__hasResult.get();
    }
    set hasResult(newValue: boolean) {
        this.__hasResult.set(newValue);
    }
    private __result: ObservedPropertyObjectPU<FoodRecognitionResult>;
    get result() {
        return this.__result.get();
    }
    set result(newValue: FoodRecognitionResult) {
        this.__result.set(newValue);
    }
    private __selectedUri: ObservedPropertySimplePU<string>;
    get selectedUri() {
        return this.__selectedUri.get();
    }
    set selectedUri(newValue: string) {
        this.__selectedUri.set(newValue);
    }
    aboutToAppear(): void {
        Logger.info(Constants.TAG_CAMERA, 'food camera page open');
    }
    private showToast(message: string): void {
        promptAction.showToast({ message: message, duration: 2000 });
    }
    private pickImage(): void {
        const picker = new photoAccessHelper.PhotoViewPicker();
        const options = new photoAccessHelper.PhotoSelectOptions();
        options.MIMEType = photoAccessHelper.PhotoViewMIMETypes.IMAGE_TYPE;
        options.maxSelectNumber = 1;
        picker.select(options).then((pickResult: photoAccessHelper.PhotoSelectResult) => {
            const uris: string[] = pickResult.photoUris;
            if (uris.length === 0) {
                this.showToast('未选择图片');
                return;
            }
            const uri: string = uris[0];
            if (uri.trim() === '') {
                this.showToast('图片 URI 异常，请重试');
                Logger.warn(Constants.TAG_CAMERA, 'empty image uri');
                return;
            }
            this.selectedUri = uri;
            Logger.info(Constants.TAG_CAMERA, 'picked image uri=' + uri);
            this.runAnalyze(uri);
        }).catch((err: BusinessError) => {
            Logger.warn(Constants.TAG_CAMERA, 'pick image cancelled or failed, code=' + err.code.toString());
            this.showToast('已取消选择或选择失败');
        });
    }
    private analyzeSample(foodKey: string): void {
        this.selectedUri = '';
        this.runAnalyze('file://sample/' + foodKey + '.png');
    }
    private async runAnalyze(uri: string): Promise<void> {
        this.analyzing = true;
        this.hasResult = false;
        try {
            this.result = await AiAdviceService.getInstance().analyzeFoodImage(uri);
            this.hasResult = true;
            Logger.info(Constants.TAG_CAMERA, 'analyze food ok: ' + this.result.foodName);
        }
        catch (e) {
            Logger.error(Constants.TAG_CAMERA, 'analyze food failed');
            this.showToast('识别失败或超时，请重试');
        }
        finally {
            this.analyzing = false;
        }
    }
    private async saveResult(): Promise<void> {
        if (!this.hasResult) {
            return;
        }
        const advice: HealthAdvice = {
            id: DateUtil.genId('advice'),
            createTime: DateUtil.now(),
            sourceType: 'food',
            title: '食物识别：' + this.result.foodName,
            summary: this.result.summary,
            suggestion: this.result.suggestion,
            disclaimer: '以上内容仅为健康生活方式建议，不构成医疗诊断或治疗建议。',
            degraded: this.result.degraded
        };
        try {
            await AiAdviceService.getInstance().saveAdvice(advice);
            this.showToast('已保存到历史建议');
        }
        catch (e) {
            this.showToast('保存失败，请重试');
        }
    }
    private confidenceText(): string {
        return '置信度 ' + Math.round(this.result.confidence * 100).toString() + '%';
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            NavDestination.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Scroll.create();
                    Scroll.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(115:7)", "entry");
                    Scroll.width('100%');
                    Scroll.height('100%');
                    Scroll.backgroundColor('#F5F6F7');
                }, Scroll);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 14 });
                    Column.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(116:9)", "entry");
                    Column.width('100%');
                    Column.padding(16);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('选择或导入食物图片，AI 将识别食物并给出非医疗性质的建议。');
                    Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(117:11)", "entry");
                    Text.fontSize(13);
                    Text.fontColor('#999999');
                    Text.width('100%');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('从相册选择图片');
                    Button.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(122:11)", "entry");
                    Button.width('100%');
                    Button.onClick(() => {
                        this.pickImage();
                    });
                    Button.enabled(!this.analyzing);
                }, Button);
                Button.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('导入样例图片');
                    Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(129:11)", "entry");
                    Text.fontSize(14);
                    Text.fontWeight(FontWeight.Bold);
                    Text.fontColor('#333333');
                    Text.width('100%');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create({ space: 10 });
                    Row.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(135:11)", "entry");
                    Row.width('100%');
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('苹果');
                    Button.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(136:13)", "entry");
                    Button.layoutWeight(1);
                    Button.onClick(() => {
                        this.analyzeSample('apple');
                    });
                    Button.enabled(!this.analyzing);
                }, Button);
                Button.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('米饭');
                    Button.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(142:13)", "entry");
                    Button.layoutWeight(1);
                    Button.onClick(() => {
                        this.analyzeSample('rice');
                    });
                    Button.enabled(!this.analyzing);
                }, Button);
                Button.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('牛奶');
                    Button.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(148:13)", "entry");
                    Button.layoutWeight(1);
                    Button.onClick(() => {
                        this.analyzeSample('milk');
                    });
                    Button.enabled(!this.analyzing);
                }, Button);
                Button.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (this.analyzing) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create({ space: 8 });
                                Row.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(158:13)", "entry");
                                Row.width('100%');
                                Row.justifyContent(FlexAlign.Center);
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                LoadingProgress.create();
                                LoadingProgress.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(159:15)", "entry");
                                LoadingProgress.width(20);
                                LoadingProgress.height(20);
                                LoadingProgress.color('#1677FF');
                            }, LoadingProgress);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('正在识别，请稍候…');
                                Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(163:15)", "entry");
                                Text.fontSize(13);
                                Text.fontColor('#999999');
                            }, Text);
                            Text.pop();
                            Row.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(1, () => {
                        });
                    }
                }, If);
                If.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (this.hasResult) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create({ space: 10 });
                                Column.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(172:13)", "entry");
                                Column.width('100%');
                                Column.padding(14);
                                Column.borderRadius(12);
                                Column.backgroundColor('#FFFFFF');
                                Column.alignItems(HorizontalAlign.Start);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.selectedUri !== '') {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Image.create(this.selectedUri);
                                            Image.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(174:17)", "entry");
                                            Image.width('100%');
                                            Image.height(160);
                                            Image.objectFit(ImageFit.Cover);
                                            Image.borderRadius(10);
                                        }, Image);
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Column.create();
                                            Column.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(180:17)", "entry");
                                            Column.width('100%');
                                            Column.height(140);
                                            Column.borderRadius(10);
                                            Column.backgroundColor('#EEEEEE');
                                            Column.justifyContent(FlexAlign.Center);
                                        }, Column);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('样例图片');
                                            Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(181:19)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor('#999999');
                                        }, Text);
                                        Text.pop();
                                        Column.pop();
                                    });
                                }
                            }, If);
                            If.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(192:15)", "entry");
                                Row.width('100%');
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.result.foodName);
                                Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(193:17)", "entry");
                                Text.fontSize(18);
                                Text.fontWeight(FontWeight.Bold);
                                Text.fontColor('#333333');
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Blank.create();
                                Blank.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(197:17)", "entry");
                            }, Blank);
                            Blank.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.confidenceText());
                                Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(198:17)", "entry");
                                Text.fontSize(13);
                                Text.fontColor('#1677FF');
                            }, Text);
                            Text.pop();
                            Row.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.result.degraded) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('本地示例识别 · 未接入视觉接口');
                                            Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(205:17)", "entry");
                                            Text.fontSize(11);
                                            Text.fontColor('#B8860B');
                                            Text.backgroundColor('#FFF4E5');
                                            Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                                            Text.borderRadius(4);
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('约 ' + this.result.estimatedCalories.toString() + ' 千卡 / 100g');
                                Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(213:15)", "entry");
                                Text.fontSize(13);
                                Text.fontColor('#666666');
                                Text.width('100%');
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('【摘要】');
                                Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(218:15)", "entry");
                                Text.fontSize(13);
                                Text.fontWeight(FontWeight.Medium);
                                Text.fontColor('#666666');
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.result.summary);
                                Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(222:15)", "entry");
                                Text.fontSize(13);
                                Text.fontColor('#333333');
                                Text.width('100%');
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('【建议】');
                                Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(227:15)", "entry");
                                Text.fontSize(13);
                                Text.fontWeight(FontWeight.Medium);
                                Text.fontColor('#666666');
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.result.suggestion);
                                Text.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(231:15)", "entry");
                                Text.fontSize(13);
                                Text.fontColor('#333333');
                                Text.width('100%');
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Button.createWithLabel('保存建议');
                                Button.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(236:15)", "entry");
                                Button.width('100%');
                                Button.onClick(() => {
                                    this.saveResult();
                                });
                            }, Button);
                            Button.pop();
                            Column.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(1, () => {
                        });
                    }
                }, If);
                If.pop();
                Column.pop();
                Scroll.pop();
            }, { moduleName: "entry", pagePath: "entry/src/main/ets/pages/FoodCameraPage" });
            NavDestination.title('拍照识别');
            NavDestination.onBackPressed(() => {
                this.pathStack.pop();
                return true;
            });
            NavDestination.debugLine("entry/src/main/ets/pages/FoodCameraPage.ets(114:5)", "entry");
        }, NavDestination);
        NavDestination.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public __resetStateVarsOnReuse__Internal(params: Object): void {
        this.__reInitializeConsume__Internal('pathStack', "pathStack");
    }
}
