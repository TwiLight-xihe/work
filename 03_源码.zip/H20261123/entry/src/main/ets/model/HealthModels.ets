/**
 * 核心数据模型定义（model 层）。
 * 仅包含数据结构与枚举，不包含业务逻辑。
 */

/**
 * 记录类型（用于首页跳转记录页时指定默认 Tab）
 */
export enum RecordType {
  EXERCISE = 0,
  DIET = 1,
  SLEEP = 2
}

/**
 * 运动记录
 */
export interface ExerciseRecord {
  id: string;
  date: string;          // yyyy-MM-dd
  type: string;          // 跑步 / 步行 / 骑行 / 球类 / 其他
  durationMinutes: number;
  calories: number;      // 消耗热量，单位千卡
  distanceKm: number;    // 距离，单位公里，可为 0
  note: string;
}

/**
 * 饮食记录
 */
export interface DietRecord {
  id: string;
  date: string;          // yyyy-MM-dd
  mealType: string;      // 早餐 / 午餐 / 晚餐 / 加餐
  foodName: string;
  calories: number;      // 摄入热量，单位千卡
  note: string;
}

/**
 * 睡眠记录
 */
export interface SleepRecord {
  id: string;
  date: string;          // yyyy-MM-dd
  bedTime: string;       // HH:mm
  wakeTime: string;      // HH:mm
  sleepHours: number;    // 睡眠时长，单位小时
  quality: string;       // 优秀 / 良好 / 一般 / 较差
  note: string;
}

/**
 * 当日汇总（用于首页仪表盘）
 */
export interface DailySummary {
  exerciseMinutes: number;
  exerciseCalories: number;
  dietCalories: number;
  sleepHours: number;
  exerciseCount: number;
  dietCount: number;
  sleepCount: number;
}

/**
 * AI 建议（非医疗性质）
 */
export interface HealthAdvice {
  id: string;
  createTime: string;    // yyyy-MM-dd HH:mm:ss
  sourceType: string;    // analysis / qa / food
  title: string;
  summary: string;       // 摘要
  suggestion: string;    // 建议
  disclaimer: string;    // 非医疗声明
  degraded: boolean;     // 是否为本地降级建议
}

/**
 * 食物识别结果
 */
export interface FoodRecognitionResult {
  foodName: string;
  confidence: number;          // 0 ~ 1
  estimatedCalories: number;   // 每 100g 千卡
  summary: string;
  suggestion: string;
  nutrition: string;           // 主要营养成分
  portion: string;             // 建议份量
  imageUri: string;
  degraded: boolean;           // 是否为本地降级识别
}
