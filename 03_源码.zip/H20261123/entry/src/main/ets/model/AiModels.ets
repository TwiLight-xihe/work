/**
 * 云端 AI 相关数据结构定义（model 层）。
 */

/** 对话消息（OpenAI 兼容格式） */
export interface ChatMessage {
  role: string;      // system | user | assistant
  content: string;
}

/** 单条候选结果 */
export interface ChatChoice {
  message: ChatMessage;
}

/** chat/completions 响应体（仅声明需要解析的字段） */
export interface ChatCompletionResponse {
  choices: ChatChoice[];
}

/** chat/completions 请求体 */
export interface ChatRequestBody {
  model: string;
  messages: ChatMessage[];
  stream: boolean;
}

/**
 * 自定义 AI 错误：携带错误码 + 友好提示。
 * code 含义：-1 网络/超时；-2 JSON 解析异常；>=400 HTTP 状态码。
 */
export class AiServiceError extends Error {
  code: number = 0;

  constructor(code: number, message: string) {
    super(message);
    this.code = code;
  }
}

/** 一次会话（对话记忆）：多轮消息，自动持久化 */
export interface Conversation {
  id: string;
  title: string;               // 会话标题
  createTime: string;          // yyyy-MM-dd HH:mm:ss
  updateTime: string;          // yyyy-MM-dd HH:mm:ss
  messages: ChatMessage[];     // 仅 user / assistant（system 由服务层注入）
}

/** 多模态消息中的图片 url */
export interface VisionImageUrl {
  url: string;
}

/** 多模态消息 content 片段（text 或 image_url） */
export interface VisionContentPart {
  type: string;
  text?: string;
  image_url?: VisionImageUrl;
}

/** 多模态消息 */
export interface VisionMessage {
  role: string;
  content: VisionContentPart[];
}

/** 多模态请求体 */
export interface VisionRequestBody {
  model: string;
  messages: VisionMessage[];
  stream: boolean;
}

/** 视觉模型返回的食物结构化信息 */
export interface VisionFoodJson {
  foodName: string;
  caloriesPer100g: number;
  nutrition: string;
  portion: string;
  summary: string;
  suggestion: string;
}
