/**
 * 异步工具（common 层）。
 * 当前用于模拟网络延迟与超时控制；真实接入云端后，
 * 可整体替换为 @ohos.net.http 的请求封装，页面层无需改动。
 */

/** 模拟网络延迟 */
export function delay(ms: number): Promise<void> {
  return new Promise<void>((resolve: () => void) => {
    setTimeout(resolve, ms);
  });
}

/**
 * 为任务添加超时控制：超过 ms 未完成则抛出 Error。
 * 泛型 T 为任务成功时的返回值类型。
 */
export function withTimeout<T>(task: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    let settled: boolean = false;
    const timer: number = setTimeout(() => {
      if (!settled) {
        settled = true;
        reject(new Error('请求超时，请稍后重试'));
      }
    }, ms);
    task.then((value: T) => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve(value);
      }
    }, (reason: Object) => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        reject(reason);
      }
    });
  });
}
