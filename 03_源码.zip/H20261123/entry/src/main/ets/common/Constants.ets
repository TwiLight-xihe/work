/**
 * 全局常量（common 层）。
 */
export class Constants {
  // hilog 日志域，取值范围 0x0000 ~ 0xFFFF
  static readonly DOMAIN: number = 0x2A2A;

  // 各模块日志标签
  static readonly TAG_APP: string = 'HealthAgent';
  static readonly TAG_INDEX: string = 'HealthAgent.Index';
  static readonly TAG_RECORD: string = 'HealthAgent.Record';
  static readonly TAG_ADVICE: string = 'HealthAgent.Advice';
  static readonly TAG_CAMERA: string = 'HealthAgent.Camera';
  static readonly TAG_SERVICE: string = 'HealthAgent.Service';

  // 非医疗建议使用的参考阈值
  static readonly TARGET_EXERCISE_MIN: number = 30; // 每日运动分钟数目标
  static readonly TARGET_SLEEP_MIN: number = 7;     // 最低睡眠小时
  static readonly TARGET_SLEEP_MAX: number = 9;     // 最高睡眠小时
  static readonly LOW_CALORIES: number = 1200;      // 摄入偏低阈值
  static readonly HIGH_CALORIES: number = 2500;     // 摄入偏高阈值
}
