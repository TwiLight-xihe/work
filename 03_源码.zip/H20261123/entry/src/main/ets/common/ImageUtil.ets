import { image } from '@kit.ImageKit';
import { fileIo } from '@kit.CoreFileKit';
import { util } from '@kit.ArkTS';
import { GlobalContext } from './GlobalContext';
import { Logger } from './Logger';
import { Constants } from './Constants';

/**
 * 图片工具（common 层）：把图片 URI / rawfile 资源转成 base64 data URL，
 * 供云端视觉模型请求使用。
 */
export class ImageUtil {
  /** 图片 URI（file:// 或 datashare://）→ 压缩后的 JPEG data URL */
  static async uriToDataUrl(uri: string): Promise<string> {
    const file = fileIo.openSync(uri, fileIo.OpenMode.READ_ONLY);
    try {
      const src: image.ImageSource = image.createImageSource(file.fd);
      const pm: image.PixelMap = await src.createPixelMap({ desiredSize: { width: 1024, height: 1024 } });
      const packer: image.ImagePacker = image.createImagePacker();
      const buf: ArrayBuffer = await packer.packing(pm, { format: 'image/jpeg', quality: 80 });
      const dataUrl: string = ImageUtil.bytesToDataUrl(new Uint8Array(buf), 'image/jpeg');
      pm.release();
      src.release();
      packer.release();
      Logger.info(Constants.TAG_SERVICE, 'image encoded, length=' + dataUrl.length.toString());
      return dataUrl;
    } catch (e) {
      const err = e as Error;
      const msg: string = err.message !== undefined ? err.message : '未知错误';
      Logger.error(Constants.TAG_SERVICE, 'uriToDataUrl failed: ' + msg + ', uri=' + uri);
      throw new Error('图片读取失败：' + msg);
    } finally {
      fileIo.closeSync(file);
    }
  }

  /** rawfile 图片资源 → PNG data URL */
  static async rawfileToDataUrl(filename: string): Promise<string> {
    const ctx = GlobalContext.getContext();
    if (ctx === null) {
      throw new Error('context not ready');
    }
    const data: Uint8Array = await ctx.resourceManager.getRawFileContent(filename);
    return ImageUtil.bytesToDataUrl(data, 'image/png');
  }

  private static bytesToDataUrl(bytes: Uint8Array, mime: string): string {
    const b64 = new util.Base64Helper();
    return 'data:' + mime + ';base64,' + b64.encodeToStringSync(bytes);
  }
}
