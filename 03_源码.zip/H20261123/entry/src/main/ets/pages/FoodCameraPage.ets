import { promptAction } from '@kit.ArkUI';
import { photoAccessHelper } from '@kit.MediaLibraryKit';
import { BusinessError } from '@kit.BasicServicesKit';
import { FoodRecognitionResult, HealthAdvice, DietRecord } from '../model/HealthModels';
import { AiAdviceService } from '../service/AiAdviceService';
import { HealthDataService } from '../service/HealthDataService';
import { ImageUtil } from '../common/ImageUtil';
import { DateUtil } from '../common/DateUtil';
import { DataEvents } from '../common/DataEvents';
import { Logger } from '../common/Logger';
import { Constants } from '../common/Constants';
import { VisionConfig } from '../common/Config';

/**
 * 拍照识别页：
 * - 从相册选择图片 / 导入样例食物图片，走「云端视觉模型」识别；
 * - 未配置视觉 Key 或识别失败时，本地启发式降级；
 * - 识别结果可「保存为饮食记录」或「保存建议」。
 */
@Component
export struct FoodCameraPage {
  @Consume('pathStack') pathStack: NavPathStack;

  @State analyzing: boolean = false;
  @State hasResult: boolean = false;
  @State result: FoodRecognitionResult = {
    foodName: '',
    confidence: 0,
    estimatedCalories: 0,
    summary: '',
    suggestion: '',
    nutrition: '',
    portion: '',
    imageUri: '',
    degraded: false
  };
  @State selectedUri: string = '';
  @State sampleKey: string = '';

  aboutToAppear(): void {
    Logger.info(Constants.TAG_CAMERA, 'food camera page open');
  }

  private showToast(message: string): void {
    promptAction.showToast({ message: message, duration: 2000 });
  }

  private visionModeText(): string {
    if (VisionConfig.isConfigured()) {
      return '视觉模型：云端已配置（' + VisionConfig.MODEL + '）';
    }
    return '视觉模型：未配置（请在 common/Config.ets 填写 VisionConfig.API_KEY）';
  }

  private visionModeColor(): ResourceColor {
    if (VisionConfig.isConfigured()) {
      return '#1677FF';
    }
    return '#B8860B';
  }

  private pickImage(): void {
    const picker = new photoAccessHelper.PhotoViewPicker();
    const options = new photoAccessHelper.PhotoSelectOptions();
    options.MIMEType = photoAccessHelper.PhotoViewMIMETypes.IMAGE_TYPE;
    options.maxSelectNumber = 1;
    picker.select(options).then((pickResult: photoAccessHelper.PhotoSelectResult) => {
      const uris: string[] = pickResult.photoUris;
      if (uris.length === 0) {
        this.showToast('未选择图片');
        return;
      }
      const uri: string = uris[0];
      if (uri.trim() === '') {
        this.showToast('图片 URI 异常，请重试');
        Logger.warn(Constants.TAG_CAMERA, 'empty image uri');
        return;
      }
      this.selectedUri = uri;
      this.sampleKey = '';
      Logger.info(Constants.TAG_CAMERA, 'picked image uri=' + uri);
      this.analyzeByUri(uri, '');
    }).catch((err: BusinessError) => {
      Logger.warn(Constants.TAG_CAMERA, 'pick image cancelled or failed, code=' + err.code.toString());
      this.showToast('已取消选择或选择失败');
    });
  }

  private async analyzeByUri(uri: string, hint: string): Promise<void> {
    this.analyzing = true;
    this.hasResult = false;
    try {
      const dataUrl = await ImageUtil.uriToDataUrl(uri);
      this.result = await AiAdviceService.getInstance().analyzeFoodImage(dataUrl, hint);
      this.hasResult = true;
      Logger.info(Constants.TAG_CAMERA, 'analyze food ok: ' + this.result.foodName);
    } catch (e) {
      const err = e as Error;
      let msg: string = '识别失败或超时，请重试';
      if (err.message !== undefined && err.message !== '') {
        msg = err.message;
      }
      Logger.error(Constants.TAG_CAMERA, 'analyze food failed: ' + msg);
      this.showToast(msg);
    } finally {
      this.analyzing = false;
    }
  }

  private async analyzeSample(foodKey: string): Promise<void> {
    this.selectedUri = '';
    this.sampleKey = foodKey;
    this.analyzing = true;
    this.hasResult = false;
    try {
      const dataUrl = await ImageUtil.rawfileToDataUrl('food_' + foodKey + '.png');
      this.result = await AiAdviceService.getInstance().analyzeFoodImage(dataUrl, foodKey);
      this.hasResult = true;
      Logger.info(Constants.TAG_CAMERA, 'sample analyze ok: ' + this.result.foodName);
    } catch (e) {
      Logger.error(Constants.TAG_CAMERA, 'sample analyze failed');
      this.showToast('样例加载失败，请重试');
    } finally {
      this.analyzing = false;
    }
  }

  private async saveResult(): Promise<void> {
    if (!this.hasResult) {
      return;
    }
    const advice: HealthAdvice = {
      id: DateUtil.genId('advice'),
      createTime: DateUtil.now(),
      sourceType: 'food',
      title: '食物识别：' + this.result.foodName,
      summary: this.result.summary,
      suggestion: this.result.suggestion,
      disclaimer: '以上内容仅为健康生活方式建议，不构成医疗诊断或治疗建议。',
      degraded: this.result.degraded
    };
    try {
      await AiAdviceService.getInstance().saveAdvice(advice);
      this.showToast('已保存到历史建议');
    } catch (e) {
      this.showToast('保存失败，请重试');
    }
  }

  private async saveAsDiet(): Promise<void> {
    if (!this.hasResult) {
      return;
    }
    const record: DietRecord = {
      id: DateUtil.genId('diet'),
      date: DateUtil.today(),
      mealType: '加餐',
      foodName: this.result.foodName,
      calories: this.result.estimatedCalories,
      note: '拍照识别'
    };
    try {
      await HealthDataService.getInstance().addDiet(record);
      DataEvents.bump();
      this.showToast('已保存为饮食记录');
    } catch (e) {
      this.showToast('保存失败，请重试');
    }
  }

  private confidenceText(): string {
    return '置信度 ' + Math.round(this.result.confidence * 100).toString() + '%';
  }

  private suggestionLines(): string[] {
    if (!this.hasResult) {
      return [];
    }
    const parts: string[] = this.result.suggestion.split('；');
    const lines: string[] = [];
    for (let i = 0; i < parts.length; i++) {
      const p: string = parts[i].trim();
      if (p !== '') {
        lines.push(p);
      }
    }
    return lines;
  }

  build() {
    NavDestination() {
      Scroll() {
        Column({ space: 14 }) {
          Text(this.visionModeText())
            .fontSize(12)
            .fontColor(this.visionModeColor())
            .width('100%')

          Text('选择或导入食物图片，云端视觉模型将识别食物并给出非医疗性质的建议。')
            .fontSize(13)
            .fontColor('#999999')
            .width('100%')

          Button('从相册选择图片')
            .width('100%')
            .onClick(() => {
              this.pickImage();
            })
            .enabled(!this.analyzing)

          Text('导入样例图片')
            .fontSize(14)
            .fontWeight(FontWeight.Bold)
            .fontColor('#333333')
            .width('100%')

          Row({ space: 10 }) {
            Button('苹果')
              .layoutWeight(1)
              .onClick(() => {
                this.analyzeSample('apple');
              })
              .enabled(!this.analyzing)
            Button('米饭')
              .layoutWeight(1)
              .onClick(() => {
                this.analyzeSample('rice');
              })
              .enabled(!this.analyzing)
            Button('牛奶')
              .layoutWeight(1)
              .onClick(() => {
                this.analyzeSample('milk');
              })
              .enabled(!this.analyzing)
          }
          .width('100%')

          if (this.analyzing) {
            Row({ space: 8 }) {
              LoadingProgress()
                .width(20)
                .height(20)
                .color('#1677FF')
              Text('正在识别，请稍候…')
                .fontSize(13)
                .fontColor('#999999')
            }
            .width('100%')
            .justifyContent(FlexAlign.Center)
          }

          if (this.hasResult) {
            Column({ space: 10 }) {
              if (this.selectedUri !== '') {
                Image(this.selectedUri)
                  .width('100%')
                  .height(160)
                  .objectFit(ImageFit.Cover)
                  .borderRadius(10)
              } else if (this.sampleKey === 'apple') {
                Image($rawfile('food_apple.png'))
                  .width('100%')
                  .height(160)
                  .objectFit(ImageFit.Cover)
                  .borderRadius(10)
              } else if (this.sampleKey === 'rice') {
                Image($rawfile('food_rice.png'))
                  .width('100%')
                  .height(160)
                  .objectFit(ImageFit.Cover)
                  .borderRadius(10)
              } else if (this.sampleKey === 'milk') {
                Image($rawfile('food_milk.png'))
                  .width('100%')
                  .height(160)
                  .objectFit(ImageFit.Cover)
                  .borderRadius(10)
              } else {
                Column() {
                  Text('样例图片')
                    .fontSize(13)
                    .fontColor('#999999')
                }
                .width('100%')
                .height(140)
                .borderRadius(10)
                .backgroundColor('#EEEEEE')
                .justifyContent(FlexAlign.Center)
              }

              Row() {
                Text(this.result.foodName)
                  .fontSize(18)
                  .fontWeight(FontWeight.Bold)
                  .fontColor('#333333')
                Blank()
                Text(this.confidenceText())
                  .fontSize(13)
                  .fontColor('#1677FF')
              }
              .width('100%')

              if (this.result.degraded) {
                Text('本地降级识别')
                  .fontSize(11)
                  .fontColor('#B8860B')
                  .backgroundColor('#FFF4E5')
                  .padding({ left: 6, right: 6, top: 2, bottom: 2 })
                  .borderRadius(4)
              }

              Text('约 ' + this.result.estimatedCalories.toString() + ' 千卡 / 100g')
                .fontSize(13)
                .fontColor('#666666')
                .width('100%')

              if (this.result.nutrition !== '') {
                Text('【营养】')
                  .fontSize(13)
                  .fontWeight(FontWeight.Medium)
                  .fontColor('#666666')
                Text(this.result.nutrition)
                  .fontSize(13)
                  .fontColor('#333333')
                  .width('100%')
              }

              if (this.result.portion !== '') {
                Text('【份量】')
                  .fontSize(13)
                  .fontWeight(FontWeight.Medium)
                  .fontColor('#666666')
                Text(this.result.portion)
                  .fontSize(13)
                  .fontColor('#333333')
                  .width('100%')
              }

              Text('【摘要】')
                .fontSize(13)
                .fontWeight(FontWeight.Medium)
                .fontColor('#666666')
              Text(this.result.summary)
                .fontSize(13)
                .fontColor('#333333')
                .width('100%')

              Text('【建议】')
                .fontSize(13)
                .fontWeight(FontWeight.Medium)
                .fontColor('#666666')
              ForEach(this.suggestionLines(), (line: string) => {
                Row() {
                  Text('· ')
                    .fontSize(13)
                    .fontColor('#333333')
                  Text(line)
                    .fontSize(13)
                    .fontColor('#333333')
                    .layoutWeight(1)
                }
                .width('100%')
              }, (line: string, index: number) => index.toString())

              Row({ space: 10 }) {
                Button('保存为饮食记录')
                  .layoutWeight(1)
                  .onClick(() => {
                    this.saveAsDiet();
                  })
                Button('保存建议')
                  .layoutWeight(1)
                  .onClick(() => {
                    this.saveResult();
                  })
              }
              .width('100%')
            }
            .width('100%')
            .padding(14)
            .borderRadius(12)
            .backgroundColor('#FFFFFF')
            .alignItems(HorizontalAlign.Start)
          }
        }
        .width('100%')
        .padding(16)
      }
      .width('100%')
      .height('100%')
      .backgroundColor('#F5F6F7')
    }
    .title('拍照识别')
    .onBackPressed(() => {
      this.pathStack.pop();
      return true;
    })
  }
}
