import { DailySummary } from '../model/HealthModels';
import { PageName, RecordPageParams } from '../model/PageParams';
import { HealthDataService } from '../service/HealthDataService';
import { DateUtil } from '../common/DateUtil';
import { Logger } from '../common/Logger';
import { Constants } from '../common/Constants';
import { RecordPage } from './RecordPage';
import { AiAdvicePage } from './AiAdvicePage';
import { FoodCameraPage } from './FoodCameraPage';

/**
 * 首页 / 仪表盘（@Entry 根页面）。
 * 使用 Navigation + NavPathStack 管理页面栈，@Provide/@Consume 向子页共享路由栈。
 */
@Entry
@Component
struct Index {
  @Provide('pathStack') pathStack: NavPathStack = new NavPathStack();
  @State summary: DailySummary = HealthDataService.getInstance().emptySummary();
  @State loading: boolean = true;
  @State loadError: boolean = false;
  @StorageLink('healthDataVersion') @Watch('onDataVersionChanged') dataVersion: number = 0;

  aboutToAppear(): void {
    this.refreshSummary();
  }

  private onDataVersionChanged(): void {
    Logger.info(Constants.TAG_INDEX, 'data version changed, refresh summary');
    this.refreshSummary();
  }

  private async refreshSummary(): Promise<void> {
    this.loading = true;
    this.loadError = false;
    try {
      this.summary = await HealthDataService.getInstance().getDailySummary();
      Logger.info(Constants.TAG_INDEX, 'refresh summary ok');
    } catch (e) {
      this.loadError = true;
      this.summary = HealthDataService.getInstance().emptySummary();
      Logger.error(Constants.TAG_INDEX, 'refresh summary failed');
    } finally {
      this.loading = false;
    }
  }

  private goRecord(): void {
    const params: RecordPageParams = {};
    this.pathStack.pushPathByName(PageName.RECORD, params, true);
  }

  private goAdvice(): void {
    this.pathStack.pushPathByName(PageName.AI_ADVICE, undefined, true);
  }

  private goCamera(): void {
    this.pathStack.pushPathByName(PageName.FOOD_CAMERA, undefined, true);
  }

  @Builder
  PageMap(name: string) {
    if (name === PageName.RECORD) {
      RecordPage()
    } else if (name === PageName.AI_ADVICE) {
      AiAdvicePage()
    } else if (name === PageName.FOOD_CAMERA) {
      FoodCameraPage()
    }
  }

  @Builder
  SummaryCard(title: string, value: string, unit: string) {
    Column({ space: 4 }) {
      Text(title)
        .fontSize(13)
        .fontColor('#666666')
      Text(value)
        .fontSize(22)
        .fontWeight(FontWeight.Bold)
        .fontColor('#1677FF')
      Text(unit)
        .fontSize(11)
        .fontColor('#999999')
    }
    .layoutWeight(1)
    .padding(14)
    .borderRadius(12)
    .backgroundColor('#FFFFFF')
    .alignItems(HorizontalAlign.Start)
  }

  build() {
    Navigation(this.pathStack) {
      Scroll() {
        Column({ space: 16 }) {
          // 顶部标题
          Column({ space: 4 }) {
            Text('个人健康管理 Agent')
              .fontSize(22)
              .fontWeight(FontWeight.Bold)
              .fontColor('#333333')
            Text(DateUtil.today() + ' · 今天也要照顾好自己')
              .fontSize(13)
              .fontColor('#999999')
          }
          .width('100%')
          .alignItems(HorizontalAlign.Start)

          // 当日概览
          if (this.loading) {
            Column({ space: 8 }) {
              LoadingProgress()
                .width(36)
                .height(36)
                .color('#1677FF')
              Text('加载中…')
                .fontSize(13)
                .fontColor('#999999')
            }
            .width('100%')
            .padding(20)
            .justifyContent(FlexAlign.Center)
          } else if (this.loadError) {
            Column({ space: 8 }) {
              Text('数据加载失败')
                .fontSize(14)
                .fontColor('#666666')
              Button('重试')
                .fontSize(13)
                .onClick(() => {
                  this.refreshSummary();
                })
            }
            .width('100%')
            .padding(20)
            .alignItems(HorizontalAlign.Center)
          } else {
            Row({ space: 10 }) {
              this.SummaryCard('运动', this.summary.exerciseMinutes.toString(), '分钟')
              this.SummaryCard('摄入', this.summary.dietCalories.toString(), '千卡')
              this.SummaryCard('睡眠', this.summary.sleepHours.toString(), '小时')
            }
            .width('100%')
          }

          // 快捷入口
          Column({ space: 10 }) {
            Row() {
              Column({ space: 2 }) {
                Text('记录管理')
                  .fontSize(16)
                  .fontWeight(FontWeight.Medium)
                  .fontColor('#333333')
                Text('运动 / 饮食 / 睡眠的增删改查')
                  .fontSize(12)
                  .fontColor('#999999')
              }
              .alignItems(HorizontalAlign.Start)
              .layoutWeight(1)
              Text('>')
                .fontSize(18)
                .fontColor('#CCCCCC')
            }
            .width('100%')
            .padding(16)
            .borderRadius(12)
            .backgroundColor('#FFFFFF')
            .onClick(() => {
              this.goRecord();
            })

            Row() {
              Column({ space: 2 }) {
                Text('AI 分析建议')
                  .fontSize(16)
                  .fontWeight(FontWeight.Medium)
                  .fontColor('#333333')
                Text('生成今日健康分析与智能问答')
                  .fontSize(12)
                  .fontColor('#999999')
              }
              .alignItems(HorizontalAlign.Start)
              .layoutWeight(1)
              Text('>')
                .fontSize(18)
                .fontColor('#CCCCCC')
            }
            .width('100%')
            .padding(16)
            .borderRadius(12)
            .backgroundColor('#FFFFFF')
            .onClick(() => {
              this.goAdvice();
            })

            Row() {
              Column({ space: 2 }) {
                Text('拍照识别')
                  .fontSize(16)
                  .fontWeight(FontWeight.Medium)
                  .fontColor('#333333')
                Text('拍照或导入样例食物图片')
                  .fontSize(12)
                  .fontColor('#999999')
              }
              .alignItems(HorizontalAlign.Start)
              .layoutWeight(1)
              Text('>')
                .fontSize(18)
                .fontColor('#CCCCCC')
            }
            .width('100%')
            .padding(16)
            .borderRadius(12)
            .backgroundColor('#FFFFFF')
            .onClick(() => {
              this.goCamera();
            })
          }
          .width('100%')

          // 页脚提示
          Text('提示：所有建议均为非医疗性质，仅供参考。')
            .fontSize(12)
            .fontColor('#AAAAAA')
            .width('100%')
        }
        .width('100%')
        .padding(16)
        .backgroundColor('#F5F6F7')
      }
      .width('100%')
      .height('100%')
      .backgroundColor('#F5F6F7')
    }
    .mode(NavigationMode.Stack)
    .title('首页')
    .hideToolBar(true)
    .navDestination(this.PageMap)
  }
}
