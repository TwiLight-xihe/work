import { promptAction } from '@kit.ArkUI';
import { HealthAdvice } from '../model/HealthModels';
import { AiServiceError, ChatMessage, Conversation } from '../model/AiModels';
import { AiAdviceService } from '../service/AiAdviceService';
import { AiConfig } from '../common/Config';
import { Logger } from '../common/Logger';
import { Constants } from '../common/Constants';

/**
 * AI 分析 / 建议页：
 * - 结构化分析（云端 AI，未配置/失败时本地降级）
 * - 智能问答：类大模型聊天流，多会话、自动记忆（切页/重启不丢）
 * - 历史建议：查看 / 清空（持久化）
 */
@Component
export struct AiAdvicePage {
  @Consume('pathStack') pathStack: NavPathStack;

  // 结构化分析
  @State analysis: HealthAdvice = {
    id: '',
    createTime: '',
    sourceType: '',
    title: '',
    summary: '',
    suggestion: '',
    disclaimer: '',
    degraded: false
  };
  @State hasAnalysis: boolean = false;
  @State viewingHistory: boolean = false;
  @State analyzing: boolean = false;

  // 聊天流 + 会话
  @State conversations: Conversation[] = [];
  @State currentId: string = '';
  @State chatList: ChatMessage[] = [];
  @State input: string = '';
  @State sending: boolean = false;
  private scroller: Scroller = new Scroller();

  // 历史
  @State history: HealthAdvice[] = [];
  @State historyLoading: boolean = false;
  @State historyError: boolean = false;
  @State showHistory: boolean = false;

  aboutToAppear(): void {
    Logger.info(Constants.TAG_ADVICE, 'ai advice page open');
    this.loadHistory();
    this.reloadConversation();
  }

  // ===== 会话 =====
  private async reloadConversation(): Promise<void> {
    try {
      const svc = AiAdviceService.getInstance();
      this.conversations = await svc.listConversations();
      this.currentId = await svc.getCurrentId();
      this.chatList = await svc.getCurrentMessages();
    } catch (e) {
      Logger.error(Constants.TAG_ADVICE, 'reload conversation failed');
    }
  }

  private async newConversation(): Promise<void> {
    try {
      await AiAdviceService.getInstance().newConversation();
      await this.reloadConversation();
    } catch (e) {
      this.showToast('新建会话失败');
    }
  }

  private async switchConversation(id: string): Promise<void> {
    if (id === this.currentId) {
      return;
    }
    try {
      await AiAdviceService.getInstance().switchConversation(id);
      await this.reloadConversation();
    } catch (e) {
      this.showToast('切换会话失败');
    }
  }

  private confirmDeleteCurrent(): void {
    AlertDialog.show({
      title: '删除会话',
      message: '确定删除当前会话吗？删除后不可恢复。',
      autoCancel: true,
      alignment: DialogAlignment.Center,
      primaryButton: {
        value: '删除',
        fontColor: '#E84026',
        action: () => {
          this.deleteCurrentConversation();
        }
      },
      secondaryButton: {
        value: '取消',
        fontColor: '#666666',
        action: () => {
        }
      }
    });
  }

  private async deleteCurrentConversation(): Promise<void> {
    try {
      await AiAdviceService.getInstance().deleteConversation(this.currentId);
      await this.reloadConversation();
      this.showToast('已删除会话');
    } catch (e) {
      this.showToast('删除失败');
    }
  }

  // ===== 历史 =====
  private async loadHistory(): Promise<void> {
    this.historyLoading = true;
    this.historyError = false;
    try {
      this.history = await AiAdviceService.getInstance().getHistory();
    } catch (e) {
      this.historyError = true;
      this.history = [];
      Logger.error(Constants.TAG_ADVICE, 'load history failed');
    } finally {
      this.historyLoading = false;
    }
  }

  private async runAnalysis(): Promise<void> {
    this.analyzing = true;
    try {
      this.analysis = await AiAdviceService.getInstance().generateAnalysis();
      this.hasAnalysis = true;
      this.viewingHistory = false;
      Logger.info(Constants.TAG_ADVICE, 'analysis ok');
    } catch (e) {
      Logger.error(Constants.TAG_ADVICE, 'analysis failed');
      this.showToast('分析失败，请重试');
    } finally {
      this.analyzing = false;
    }
  }

  private async send(): Promise<void> {
    const q: string = this.input.trim();
    if (q === '') {
      this.showToast('请先输入问题');
      return;
    }
    this.chatList = [...this.chatList, { role: 'user', content: q }];
    this.input = '';
    this.sending = true;
    this.scrollToBottom();
    try {
      await AiAdviceService.getInstance().askQuestion(q);
      await this.reloadConversation();
    } catch (e) {
      this.showToast('回答失败，请重试');
      await this.reloadConversation();
    } finally {
      this.sending = false;
      this.scrollToBottom();
    }
  }

  private scrollToBottom(): void {
    setTimeout(() => {
      this.scroller.scrollEdge(Edge.Bottom);
    }, 50);
  }

  private async saveAnalysis(): Promise<void> {
    if (!this.hasAnalysis) {
      return;
    }
    try {
      await AiAdviceService.getInstance().saveAdvice(this.analysis);
      this.showToast('已保存到历史建议');
      await this.loadHistory();
    } catch (e) {
      this.showToast('保存失败，请重试');
    }
  }

  private viewHistoryItem(item: HealthAdvice): void {
    this.analysis = item;
    this.hasAnalysis = true;
    this.viewingHistory = true;
    this.showHistory = false;
  }

  private modeText(): string {
    if (AiConfig.isApiKeyConfigured()) {
      return '当前：云端模式（' + AiConfig.MODEL + '）';
    }
    return '当前：本地降级模式（未配置 API Key，请到 common/Config.ets 填写）';
  }

  private async testConnection(): Promise<void> {
    this.analyzing = true;
    try {
      await AiAdviceService.getInstance().testConnection();
      this.showToast('云端连接成功');
    } catch (e) {
      const err = e as AiServiceError;
      let msg: string = '连接失败';
      if (err.message !== undefined && err.message !== '') {
        msg = err.message;
      }
      this.showToast(msg);
    } finally {
      this.analyzing = false;
    }
  }

  private confirmClearHistory(): void {
    AlertDialog.show({
      title: '清空历史',
      message: '确定清空全部历史建议吗？',
      autoCancel: true,
      alignment: DialogAlignment.Center,
      primaryButton: {
        value: '清空',
        fontColor: '#E84026',
        action: () => {
          this.doClearHistory();
        }
      },
      secondaryButton: {
        value: '取消',
        fontColor: '#666666',
        action: () => {
        }
      }
    });
  }

  private async doClearHistory(): Promise<void> {
    try {
      await AiAdviceService.getInstance().clearHistory();
      this.history = [];
      this.showToast('已清空历史');
    } catch (e) {
      this.showToast('清空失败，请重试');
    }
  }

  private showToast(message: string): void {
    promptAction.showToast({ message: message, duration: 2000 });
  }

  private tabWeight(active: boolean): FontWeight {
    if (active) {
      return FontWeight.Bold;
    }
    return FontWeight.Normal;
  }

  private tabColor(active: boolean): ResourceColor {
    if (active) {
      return '#1677FF';
    }
    return '#666666';
  }

  private tabBg(active: boolean): ResourceColor {
    if (active) {
      return '#E8F1FF';
    }
    return '#FFFFFF';
  }

  private convWeight(id: string): FontWeight {
    if (id === this.currentId) {
      return FontWeight.Bold;
    }
    return FontWeight.Normal;
  }

  private convColor(id: string): ResourceColor {
    if (id === this.currentId) {
      return '#FFFFFF';
    }
    return '#333333';
  }

  private convBg(id: string): ResourceColor {
    if (id === this.currentId) {
      return '#1677FF';
    }
    return '#FFFFFF';
  }

  @Builder
  AnalysisCard(item: HealthAdvice) {
    Column({ space: 8 }) {
      Row() {
        Text(item.title)
          .fontSize(16)
          .fontWeight(FontWeight.Bold)
          .fontColor('#333333')
          .layoutWeight(1)
        if (!this.viewingHistory) {
          Button('保存')
            .fontSize(12)
            .height(28)
            .onClick(() => {
              this.saveAnalysis();
            })
        }
      }
      .width('100%')

      if (item.degraded) {
        Text('本地降级建议')
          .fontSize(11)
          .fontColor('#B8860B')
          .backgroundColor('#FFF4E5')
          .padding({ left: 6, right: 6, top: 2, bottom: 2 })
          .borderRadius(4)
      }

      Text(item.createTime)
        .fontSize(11)
        .fontColor('#999999')
        .width('100%')

      Text('【摘要】')
        .fontSize(13)
        .fontWeight(FontWeight.Medium)
        .fontColor('#666666')
      Text(item.summary)
        .fontSize(13)
        .fontColor('#333333')
        .width('100%')

      if (item.suggestion !== '') {
        Text('【建议】')
          .fontSize(13)
          .fontWeight(FontWeight.Medium)
          .fontColor('#666666')
        Text(item.suggestion)
          .fontSize(13)
          .fontColor('#333333')
          .width('100%')
      }

      Text(item.disclaimer)
        .fontSize(11)
        .fontColor('#AAAAAA')
        .width('100%')
    }
    .width('100%')
    .padding(14)
    .borderRadius(12)
    .backgroundColor('#FFFFFF')
    .alignItems(HorizontalAlign.Start)
  }

  @Builder
  Bubble(msg: ChatMessage) {
    Row() {
      if (msg.role === 'user') {
        Blank()
        Text(msg.content)
          .fontSize(15)
          .fontColor('#FFFFFF')
          .backgroundColor('#1677FF')
          .padding({ left: 12, right: 12, top: 8, bottom: 8 })
          .borderRadius(10)
          .constraintSize({ maxWidth: '80%' })
      } else {
        Text(msg.content)
          .fontSize(15)
          .fontColor('#333333')
          .backgroundColor('#FFFFFF')
          .padding({ left: 12, right: 12, top: 8, bottom: 8 })
          .borderRadius(10)
          .constraintSize({ maxWidth: '80%' })
        Blank()
      }
    }
    .width('100%')
  }

  build() {
    NavDestination() {
      Column() {
        // ===== 顶部固定区 =====
        Column({ space: 8 }) {
          Text(this.modeText())
            .fontSize(12)
            .fontColor('#666666')
            .width('100%')

          Row({ space: 8 }) {
            Button('生成今日分析')
              .fontSize(13)
              .height(36)
              .layoutWeight(1)
              .onClick(() => {
                this.runAnalysis();
              })
              .enabled(!this.analyzing && !this.sending)
            Button('测试连接')
              .fontSize(13)
              .height(36)
              .layoutWeight(1)
              .onClick(() => {
                this.testConnection();
              })
              .enabled(!this.analyzing && !this.sending)
          }
          .width('100%')

          // 会话栏（仅对话模式）
          if (!this.showHistory) {
            Row({ space: 8 }) {
              Text('＋ 新对话')
                .fontSize(13)
                .fontColor('#1677FF')
                .backgroundColor('#FFFFFF')
                .padding({ left: 10, right: 10, top: 6, bottom: 6 })
                .borderRadius(16)
                .onClick(() => {
                  this.newConversation();
                })

              Scroll() {
                Row({ space: 8 }) {
                  ForEach(this.conversations, (conv: Conversation) => {
                    Text(conv.title)
                      .fontSize(13)
                      .fontWeight(this.convWeight(conv.id))
                      .fontColor(this.convColor(conv.id))
                      .backgroundColor(this.convBg(conv.id))
                      .padding({ left: 10, right: 10, top: 6, bottom: 6 })
                      .borderRadius(16)
                      .maxLines(1)
                      .onClick(() => {
                        this.switchConversation(conv.id);
                      })
                  }, (conv: Conversation) => conv.id)
                }
              }
              .layoutWeight(1)
              .scrollable(ScrollDirection.Horizontal)
              .scrollBar(BarState.Off)

              Text('删除')
                .fontSize(12)
                .fontColor('#E84026')
                .backgroundColor('#FFFFFF')
                .padding({ left: 8, right: 8, top: 6, bottom: 6 })
                .borderRadius(14)
                .onClick(() => {
                  this.confirmDeleteCurrent();
                })
            }
            .width('100%')
          }

          Row({ space: 0 }) {
            Text('对话')
              .fontSize(14)
              .fontWeight(this.tabWeight(!this.showHistory))
              .fontColor(this.tabColor(!this.showHistory))
              .backgroundColor(this.tabBg(!this.showHistory))
              .textAlign(TextAlign.Center)
              .layoutWeight(1)
              .padding({ top: 6, bottom: 6 })
              .borderRadius(8)
              .onClick(() => {
                this.showHistory = false;
              })
            Text('历史')
              .fontSize(14)
              .fontWeight(this.tabWeight(this.showHistory))
              .fontColor(this.tabColor(this.showHistory))
              .backgroundColor(this.tabBg(this.showHistory))
              .textAlign(TextAlign.Center)
              .layoutWeight(1)
              .padding({ top: 6, bottom: 6 })
              .borderRadius(8)
              .onClick(() => {
                this.showHistory = true;
              })
          }
          .width('100%')
          .padding(3)
          .borderRadius(10)
          .backgroundColor('#FFFFFF')
        }
        .width('100%')
        .padding({ left: 12, right: 12, top: 12, bottom: 6 })

        // ===== 中间滚动区 =====
        List({ space: 10, scroller: this.scroller }) {
          if (!this.showHistory) {
            if (this.hasAnalysis) {
              ListItem() {
                this.AnalysisCard(this.analysis)
              }
            }

            if (this.chatList.length === 0 && !this.hasAnalysis) {
              ListItem() {
                Column({ space: 6 }) {
                  Text('开始和 AI 对话吧')
                    .fontSize(15)
                    .fontColor('#666666')
                  Text('例如：怎样改善睡眠？')
                    .fontSize(13)
                    .fontColor('#999999')
                }
                .width('100%')
                .padding(30)
                .alignItems(HorizontalAlign.Center)
              }
            }

            ForEach(this.chatList, (msg: ChatMessage) => {
              ListItem() {
                this.Bubble(msg)
              }
            }, (msg: ChatMessage, index: number) => index.toString())

            if (this.sending) {
              ListItem() {
                Row({ space: 8 }) {
                  LoadingProgress()
                    .width(16)
                    .height(16)
                    .color('#1677FF')
                  Text('思考中…')
                    .fontSize(13)
                    .fontColor('#999999')
                }
                .width('100%')
                .padding(6)
              }
            }
          } else {
            ListItem() {
              Row() {
                Text('历史建议')
                  .fontSize(15)
                  .fontWeight(FontWeight.Bold)
                  .fontColor('#333333')
                Blank()
                Button('清空')
                  .fontSize(12)
                  .height(28)
                  .backgroundColor('#FDE8E8')
                  .fontColor('#E84026')
                  .onClick(() => {
                    this.confirmClearHistory();
                  })
              }
              .width('100%')
            }

            if (this.historyLoading) {
              ListItem() {
                Column() {
                  LoadingProgress()
                    .width(32)
                    .height(32)
                    .color('#1677FF')
                }
                .width('100%')
                .padding(20)
                .justifyContent(FlexAlign.Center)
              }
            } else if (this.historyError) {
              ListItem() {
                Column({ space: 8 }) {
                  Text('历史加载失败')
                    .fontSize(13)
                    .fontColor('#666666')
                  Button('重试')
                    .fontSize(12)
                    .onClick(() => {
                      this.loadHistory();
                    })
                }
                .width('100%')
                .padding(16)
                .alignItems(HorizontalAlign.Center)
              }
            } else if (this.history.length === 0) {
              ListItem() {
                Text('暂无历史建议')
                  .fontSize(13)
                  .fontColor('#999999')
                  .width('100%')
                  .padding(20)
                  .textAlign(TextAlign.Center)
              }
            } else {
              ForEach(this.history, (item: HealthAdvice) => {
                ListItem() {
                  Column({ space: 4 }) {
                    Text(item.title)
                      .fontSize(14)
                      .fontWeight(FontWeight.Medium)
                      .fontColor('#333333')
                    Text(item.summary)
                      .fontSize(12)
                      .fontColor('#999999')
                      .maxLines(3)
                      .textOverflow({ overflow: TextOverflow.Ellipsis })
                    Text(item.createTime)
                      .fontSize(11)
                      .fontColor('#BBBBBB')
                  }
                  .width('100%')
                  .padding(12)
                  .borderRadius(10)
                  .backgroundColor('#FFFFFF')
                  .alignItems(HorizontalAlign.Start)
                  .onClick(() => {
                    this.viewHistoryItem(item);
                  })
                }
              }, (item: HealthAdvice) => item.id)
            }
          }
        }
        .width('100%')
        .layoutWeight(1)
        .padding({ left: 12, right: 12, top: 8, bottom: 8 })
        .scrollBar(BarState.Off)

        // ===== 底部输入区（仅对话模式） =====
        if (!this.showHistory) {
          Row({ space: 8 }) {
            TextInput({ placeholder: '输入你的问题…', text: $$this.input })
              .layoutWeight(1)
              .height(40)
            Button('发送')
              .fontSize(14)
              .onClick(() => {
                this.send();
              })
              .enabled(!this.sending)
          }
          .width('100%')
          .padding({ left: 12, right: 12, top: 6, bottom: 10 })
          .backgroundColor('#FFFFFF')
        }
      }
      .width('100%')
      .height('100%')
      .backgroundColor('#F5F6F7')
    }
    .title('AI 分析与建议')
    .onBackPressed(() => {
      this.pathStack.pop();
      return true;
    })
  }
}
