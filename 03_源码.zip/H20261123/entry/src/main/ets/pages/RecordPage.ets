import { promptAction } from '@kit.ArkUI';
import { RecordType, ExerciseRecord, DietRecord, SleepRecord } from '../model/HealthModels';
import { PageName, RecordPageParams } from '../model/PageParams';
import { HealthDataService } from '../service/HealthDataService';
import { DateUtil } from '../common/DateUtil';
import { Logger } from '../common/Logger';
import { Constants } from '../common/Constants';
import { DataEvents } from '../common/DataEvents';

/**
 * 记录页：运动 / 饮食 / 睡眠三类记录的增删改查（CRUD）。
 * 通过 Navigation 参数指定默认 Tab；空参数时回退到默认类型。
 */
@Component
export struct RecordPage {
  @Consume('pathStack') pathStack: NavPathStack;

  @State currentType: RecordType = RecordType.EXERCISE;
  @State loading: boolean = true;
  @State loadError: boolean = false;
  @State exerciseList: ExerciseRecord[] = [];
  @State dietList: DietRecord[] = [];
  @State sleepList: SleepRecord[] = [];

  // 表单状态
  @State editing: boolean = false;
  @State editingId: string = '';
  @State formDate: string = '';
  @State formNote: string = '';
  @State formExerciseTypeIndex: number = 0;
  @State formDuration: string = '';
  @State formCalories: string = '';
  @State formDistance: string = '';
  @State formMealTypeIndex: number = 0;
  @State formFoodName: string = '';
  @State formDietCalories: string = '';
  @State formBedTime: string = '23:00';
  @State formWakeTime: string = '07:00';
  @State formSleepQualityIndex: number = 0;

  private exerciseOptions: SelectOption[] = [
    { value: '跑步' },
    { value: '步行' },
    { value: '骑行' },
    { value: '球类' },
    { value: '其他' }
  ];
  private mealOptions: SelectOption[] = [
    { value: '早餐' },
    { value: '午餐' },
    { value: '晚餐' },
    { value: '加餐' }
  ];
  private qualityOptions: SelectOption[] = [
    { value: '优秀' },
    { value: '良好' },
    { value: '一般' },
    { value: '较差' }
  ];

  aboutToAppear(): void {
    const params = this.pathStack.getParamByName(PageName.RECORD) as RecordPageParams | undefined;
    if (params !== undefined && params.recordType !== undefined) {
      this.currentType = params.recordType;
      Logger.info(Constants.TAG_RECORD, 'open with recordType=' + this.currentType.toString());
    } else {
      Logger.warn(Constants.TAG_RECORD, 'no recordType param, use default');
    }
    this.loadAll();
  }

  // ===== 数据加载 =====
  private async loadAll(): Promise<void> {
    this.loading = true;
    this.loadError = false;
    try {
      const service = HealthDataService.getInstance();
      this.exerciseList = await service.listExercise();
      this.dietList = await service.listDiet();
      this.sleepList = await service.listSleep();
      Logger.info(Constants.TAG_RECORD, 'load all records ok');
    } catch (e) {
      this.loadError = true;
      this.exerciseList = [];
      this.dietList = [];
      this.sleepList = [];
      Logger.error(Constants.TAG_RECORD, 'load all records failed');
    } finally {
      this.loading = false;
    }
  }

  // ===== 交互 =====
  private switchType(type: RecordType): void {
    if (this.currentType === type) {
      return;
    }
    this.currentType = type;
    this.editing = false;
  }

  private startAdd(): void {
    this.editingId = '';
    this.formDate = DateUtil.today();
    this.formNote = '';
    this.formExerciseTypeIndex = 0;
    this.formDuration = '';
    this.formCalories = '';
    this.formDistance = '';
    this.formMealTypeIndex = 0;
    this.formFoodName = '';
    this.formDietCalories = '';
    this.formBedTime = '23:00';
    this.formWakeTime = '07:00';
    this.formSleepQualityIndex = 0;
    this.editing = true;
  }

  private startEditById(id: string): void {
    this.editingId = id;
    this.formNote = '';
    if (this.currentType === RecordType.EXERCISE) {
      const found = this.exerciseList.find((item: ExerciseRecord) => item.id === id);
      if (found !== undefined) {
        this.formDate = found.date;
        this.formNote = found.note;
        this.formExerciseTypeIndex = this.indexOfValue(this.exerciseOptions, found.type);
        this.formDuration = found.durationMinutes.toString();
        this.formCalories = found.calories.toString();
        this.formDistance = found.distanceKm.toString();
      }
    } else if (this.currentType === RecordType.DIET) {
      const found = this.dietList.find((item: DietRecord) => item.id === id);
      if (found !== undefined) {
        this.formDate = found.date;
        this.formNote = found.note;
        this.formMealTypeIndex = this.indexOfValue(this.mealOptions, found.mealType);
        this.formFoodName = found.foodName;
        this.formDietCalories = found.calories.toString();
      }
    } else {
      const found = this.sleepList.find((item: SleepRecord) => item.id === id);
      if (found !== undefined) {
        this.formDate = found.date;
        this.formNote = found.note;
        this.formBedTime = found.bedTime;
        this.formWakeTime = found.wakeTime;
        this.formSleepQualityIndex = this.indexOfValue(this.qualityOptions, found.quality);
      }
    }
    this.editing = true;
  }

  private indexOfValue(options: SelectOption[], value: string): number {
    for (let i = 0; i < options.length; i++) {
      const v: string = options[i].value as string;
      if (v === value) {
        return i;
      }
    }
    return 0;
  }

  private cancelEdit(): void {
    this.editing = false;
  }

  private showToast(message: string): void {
    promptAction.showToast({ message: message, duration: 2000 });
  }

  private validateForm(): string {
    if (this.formDate.trim() === '') {
      return '请填写日期';
    }
    if (this.currentType === RecordType.EXERCISE) {
      const duration = Number(this.formDuration.trim());
      if (this.formDuration.trim() === '' || isNaN(duration) || duration <= 0) {
        return '请填写有效的运动时长（分钟）';
      }
      const calories = Number(this.formCalories.trim());
      if (this.formCalories.trim() === '' || isNaN(calories) || calories < 0) {
        return '请填写有效的消耗热量（千卡）';
      }
      const distance = Number(this.formDistance.trim());
      if (this.formDistance.trim() === '' || isNaN(distance) || distance < 0) {
        return '请填写有效的距离（公里）';
      }
    } else if (this.currentType === RecordType.DIET) {
      if (this.formFoodName.trim() === '') {
        return '请填写食物名称';
      }
      const calories = Number(this.formDietCalories.trim());
      if (this.formDietCalories.trim() === '' || isNaN(calories) || calories <= 0) {
        return '请填写有效的热量（千卡）';
      }
    } else {
      if (this.formBedTime.trim() === '' || this.formWakeTime.trim() === '') {
        return '请填写入睡与起床时间';
      }
      if (this.formBedTime.trim() === this.formWakeTime.trim()) {
        return '入睡与起床时间不能相同';
      }
    }
    return '';
  }

  private async save(): Promise<void> {
    const err = this.validateForm();
    if (err !== '') {
      this.showToast(err);
      return;
    }
    try {
      const service = HealthDataService.getInstance();
      if (this.currentType === RecordType.EXERCISE) {
        const record: ExerciseRecord = {
          id: this.editingId === '' ? DateUtil.genId('ex') : this.editingId,
          date: this.formDate.trim(),
          type: this.exerciseOptions[this.formExerciseTypeIndex].value as string,
          durationMinutes: Number(this.formDuration.trim()),
          calories: Number(this.formCalories.trim()),
          distanceKm: Number(this.formDistance.trim()),
          note: this.formNote.trim()
        };
        if (this.editingId === '') {
          await service.addExercise(record);
        } else {
          await service.updateExercise(record);
        }
      } else if (this.currentType === RecordType.DIET) {
        const record: DietRecord = {
          id: this.editingId === '' ? DateUtil.genId('diet') : this.editingId,
          date: this.formDate.trim(),
          mealType: this.mealOptions[this.formMealTypeIndex].value as string,
          foodName: this.formFoodName.trim(),
          calories: Number(this.formDietCalories.trim()),
          note: this.formNote.trim()
        };
        if (this.editingId === '') {
          await service.addDiet(record);
        } else {
          await service.updateDiet(record);
        }
      } else {
        const record: SleepRecord = {
          id: this.editingId === '' ? DateUtil.genId('sleep') : this.editingId,
          date: this.formDate.trim(),
          bedTime: this.formBedTime.trim(),
          wakeTime: this.formWakeTime.trim(),
          sleepHours: DateUtil.sleepHours(this.formBedTime.trim(), this.formWakeTime.trim()),
          quality: this.qualityOptions[this.formSleepQualityIndex].value as string,
          note: this.formNote.trim()
        };
        if (this.editingId === '') {
          await service.addSleep(record);
        } else {
          await service.updateSleep(record);
        }
      }
      this.showToast('保存成功');
      this.editing = false;
      await this.loadAll();
      DataEvents.bump();
    } catch (e) {
      Logger.error(Constants.TAG_RECORD, 'save record failed');
      this.showToast('保存失败，请重试');
    }
  }

  private confirmDelete(id: string): void {
    AlertDialog.show({
      title: '删除确认',
      message: '确定删除这条记录吗？删除后不可恢复。',
      autoCancel: true,
      alignment: DialogAlignment.Center,
      primaryButton: {
        value: '删除',
        fontColor: '#E84026',
        action: () => {
          this.doDelete(id);
        }
      },
      secondaryButton: {
        value: '取消',
        fontColor: '#666666',
        action: () => {
        }
      }
    });
  }

  private async doDelete(id: string): Promise<void> {
    try {
      const service = HealthDataService.getInstance();
      if (this.currentType === RecordType.EXERCISE) {
        await service.deleteExercise(id);
      } else if (this.currentType === RecordType.DIET) {
        await service.deleteDiet(id);
      } else {
        await service.deleteSleep(id);
      }
      this.showToast('删除成功');
      await this.loadAll();
      DataEvents.bump();
    } catch (e) {
      Logger.error(Constants.TAG_RECORD, 'delete record failed');
      this.showToast('删除失败，请重试');
    }
  }

  // ===== 视图辅助 =====
  private tabColor(type: RecordType): ResourceColor {
    if (type === this.currentType) {
      return '#1677FF';
    }
    return '#666666';
  }

  private tabBg(type: RecordType): ResourceColor {
    if (type === this.currentType) {
      return '#E8F1FF';
    }
    return '#FFFFFF';
  }

  private tabWeight(type: RecordType): FontWeight {
    if (type === this.currentType) {
      return FontWeight.Bold;
    }
    return FontWeight.Normal;
  }

  private formTitle(): string {
    if (this.editingId === '') {
      return '新增记录';
    }
    return '编辑记录';
  }

  private computedSleepHours(): number {
    return DateUtil.sleepHours(this.formBedTime.trim(), this.formWakeTime.trim());
  }

  // ===== UI Builder =====
  @Builder
  TabItem(label: string, type: RecordType) {
    Text(label)
      .fontSize(14)
      .fontWeight(this.tabWeight(type))
      .fontColor(this.tabColor(type))
      .backgroundColor(this.tabBg(type))
      .textAlign(TextAlign.Center)
      .layoutWeight(1)
      .padding({ top: 8, bottom: 8 })
      .borderRadius(8)
      .onClick(() => {
        this.switchType(type);
      })
  }

  @Builder
  TypeTabs() {
    Row() {
      this.TabItem('运动', RecordType.EXERCISE)
      this.TabItem('饮食', RecordType.DIET)
      this.TabItem('睡眠', RecordType.SLEEP)
    }
    .width('100%')
    .padding(4)
    .borderRadius(12)
    .backgroundColor('#FFFFFF')
  }

  @Builder
  FieldLabel(text: string) {
    Text(text)
      .fontSize(13)
      .fontColor('#666666')
      .width('100%')
      .margin({ top: 12, bottom: 6 })
  }

  @Builder
  FormFields() {
    if (this.currentType === RecordType.EXERCISE) {
      this.FieldLabel('运动类型')
      Select(this.exerciseOptions)
        .selected(this.formExerciseTypeIndex)
        .value(this.exerciseOptions[this.formExerciseTypeIndex].value)
        .onSelect((index: number) => {
          this.formExerciseTypeIndex = index;
        })
        .width('100%')

      this.FieldLabel('时长（分钟）')
      TextInput({ placeholder: '例如 30', text: $$this.formDuration })
        .width('100%')

      this.FieldLabel('消耗热量（千卡）')
      TextInput({ placeholder: '例如 200', text: $$this.formCalories })
        .width('100%')

      this.FieldLabel('距离（公里）')
      TextInput({ placeholder: '例如 3.2', text: $$this.formDistance })
        .width('100%')
    } else if (this.currentType === RecordType.DIET) {
      this.FieldLabel('餐次')
      Select(this.mealOptions)
        .selected(this.formMealTypeIndex)
        .value(this.mealOptions[this.formMealTypeIndex].value)
        .onSelect((index: number) => {
          this.formMealTypeIndex = index;
        })
        .width('100%')

      this.FieldLabel('食物名称')
      TextInput({ placeholder: '例如 燕麦牛奶', text: $$this.formFoodName })
        .width('100%')

      this.FieldLabel('热量（千卡）')
      TextInput({ placeholder: '例如 320', text: $$this.formDietCalories })
        .width('100%')
    } else {
      this.FieldLabel('入睡时间（HH:mm）')
      TextInput({ placeholder: '例如 23:30', text: $$this.formBedTime })
        .width('100%')

      this.FieldLabel('起床时间（HH:mm）')
      TextInput({ placeholder: '例如 07:00', text: $$this.formWakeTime })
        .width('100%')

      this.FieldLabel('睡眠质量')
      Select(this.qualityOptions)
        .selected(this.formSleepQualityIndex)
        .value(this.qualityOptions[this.formSleepQualityIndex].value)
        .onSelect((index: number) => {
          this.formSleepQualityIndex = index;
        })
        .width('100%')

      Text('预计睡眠时长：' + this.computedSleepHours().toString() + ' 小时')
        .fontSize(13)
        .fontColor('#1677FF')
        .width('100%')
        .margin({ top: 12 })
    }
  }

  @Builder
  EditForm() {
    Scroll() {
      Column() {
        Row() {
          Text(this.formTitle())
            .fontSize(17)
            .fontWeight(FontWeight.Bold)
            .fontColor('#333333')
          Blank()
          Text('取消')
            .fontSize(14)
            .fontColor('#1677FF')
            .onClick(() => {
              this.cancelEdit();
            })
        }
        .width('100%')

        this.FieldLabel('日期（yyyy-MM-dd）')
        TextInput({ placeholder: '例如 2026-11-23', text: $$this.formDate })
          .width('100%')

        this.FormFields()

        this.FieldLabel('备注（可选）')
        TextArea({ placeholder: '补充说明（可选）', text: $$this.formNote })
          .width('100%')
          .height(80)

        Button('保存')
          .width('100%')
          .margin({ top: 20 })
          .onClick(() => {
            this.save();
          })
      }
      .width('100%')
      .padding(16)
    }
    .width('100%')
    .layoutWeight(1)
    .backgroundColor('#F5F6F7')
  }

  @Builder
  EmptyState(text: string) {
    Column({ space: 12 }) {
      Text(text)
        .fontSize(14)
        .fontColor('#999999')
      Button('立即新增')
        .fontSize(13)
        .onClick(() => {
          this.startAdd();
        })
    }
    .width('100%')
    .padding(30)
    .alignItems(HorizontalAlign.Center)
  }

  @Builder
  RecordListItem(title: string, subtitle: string, note: string, id: string) {
    ListItem() {
      Row() {
        Column({ space: 4 }) {
          Text(title)
            .fontSize(16)
            .fontWeight(FontWeight.Medium)
            .fontColor('#333333')
          Text(subtitle)
            .fontSize(13)
            .fontColor('#666666')
          if (note !== '') {
            Text('备注：' + note)
              .fontSize(12)
              .fontColor('#999999')
          }
        }
        .alignItems(HorizontalAlign.Start)
        .layoutWeight(1)

        Column({ space: 8 }) {
          Button('编辑')
            .fontSize(12)
            .height(28)
            .onClick(() => {
              this.startEditById(id);
            })
          Button('删除')
            .fontSize(12)
            .height(28)
            .backgroundColor('#FDE8E8')
            .fontColor('#E84026')
            .onClick(() => {
              this.confirmDelete(id);
            })
        }
      }
      .width('100%')
      .padding(14)
      .borderRadius(12)
      .backgroundColor('#FFFFFF')
      .alignItems(VerticalAlign.Center)
    }
  }

  @Builder
  ListContent() {
    Column({ space: 10 }) {
      Button('+ 新增记录')
        .width('100%')
        .onClick(() => {
          this.startAdd();
        })

      if (this.currentType === RecordType.EXERCISE) {
        if (this.exerciseList.length === 0) {
          this.EmptyState('暂无运动记录')
        } else {
          List({ space: 10 }) {
            ForEach(this.exerciseList, (item: ExerciseRecord) => {
              this.RecordListItem(
                item.type,
                item.durationMinutes.toString() + ' 分钟 · 消耗 ' + item.calories.toString() +
                  ' 千卡 · ' + item.distanceKm.toString() + ' 公里',
                item.note,
                item.id
              )
            }, (item: ExerciseRecord) => item.id)
          }
          .width('100%')
          .layoutWeight(1)
          .scrollBar(BarState.Off)
        }
      } else if (this.currentType === RecordType.DIET) {
        if (this.dietList.length === 0) {
          this.EmptyState('暂无饮食记录')
        } else {
          List({ space: 10 }) {
            ForEach(this.dietList, (item: DietRecord) => {
              this.RecordListItem(
                item.mealType + ' · ' + item.foodName,
                item.calories.toString() + ' 千卡 · ' + item.date,
                item.note,
                item.id
              )
            }, (item: DietRecord) => item.id)
          }
          .width('100%')
          .layoutWeight(1)
          .scrollBar(BarState.Off)
        }
      } else {
        if (this.sleepList.length === 0) {
          this.EmptyState('暂无睡眠记录')
        } else {
          List({ space: 10 }) {
            ForEach(this.sleepList, (item: SleepRecord) => {
              this.RecordListItem(
                item.quality + ' · ' + item.sleepHours.toString() + ' 小时',
                item.bedTime + ' 入睡 · ' + item.wakeTime + ' 起床 · ' + item.date,
                item.note,
                item.id
              )
            }, (item: SleepRecord) => item.id)
          }
          .width('100%')
          .layoutWeight(1)
          .scrollBar(BarState.Off)
        }
      }
    }
    .width('100%')
    .layoutWeight(1)
  }

  build() {
    NavDestination() {
      Column({ space: 10 }) {
        this.TypeTabs()
        if (this.editing) {
          this.EditForm()
        } else if (this.loading) {
          Column({ space: 10 }) {
            LoadingProgress()
              .width(40)
              .height(40)
              .color('#1677FF')
            Text('加载中…')
              .fontSize(13)
              .fontColor('#999999')
          }
          .width('100%')
          .layoutWeight(1)
          .justifyContent(FlexAlign.Center)
        } else if (this.loadError) {
          Column({ space: 10 }) {
            Text('数据加载失败')
              .fontSize(14)
              .fontColor('#666666')
            Button('重试')
              .fontSize(13)
              .onClick(() => {
                this.loadAll();
              })
          }
          .width('100%')
          .layoutWeight(1)
          .justifyContent(FlexAlign.Center)
        } else {
          this.ListContent()
        }
      }
      .width('100%')
      .height('100%')
      .padding(12)
      .backgroundColor('#F5F6F7')
    }
    .title('健康记录')
    .onBackPressed(() => {
      this.pathStack.pop();
      Logger.info(Constants.TAG_RECORD, 'back to dashboard');
      return true;
    })
  }
}
