import { HealthAdvice, DailySummary, FoodRecognitionResult } from '../model/HealthModels';
import { ChatMessage, AiServiceError, Conversation } from '../model/AiModels';
import { HealthDataService } from './HealthDataService';
import { HealthRepository } from './HealthRepository';
import { HealthAiService } from './HealthAiService';
import { AiConfig } from '../common/Config';
import { DateUtil } from '../common/DateUtil';
import { delay } from '../common/AsyncUtil';
import { Logger } from '../common/Logger';
import { Constants } from '../common/Constants';

/**
 * AI 建议服务（service 层，业务编排）。
 * 职责：
 * - 会话（对话记忆）管理：多会话、自动持久化、切换/新建/删除；
 * - 把「运动/饮食/睡眠记录」结构化拼接进提示词，调用云端 AI；
 * - 云端未配置或调用失败时降级到本地规则；
 * - 建议历史委托 HealthRepository 持久化。
 */
export class AiAdviceService {
  private static instance: AiAdviceService | null = null;
  private ai: HealthAiService = HealthAiService.getInstance();
  private repo: HealthRepository = HealthRepository.getInstance();
  private conversations: Conversation[] = [];
  private currentId: string = '';
  private loaded: boolean = false;

  static getInstance(): AiAdviceService {
    if (AiAdviceService.instance === null) {
      AiAdviceService.instance = new AiAdviceService();
    }
    return AiAdviceService.instance;
  }

  private constructor() {
  }

  // ===== 会话（记忆）管理 =====
  private async ensureLoaded(): Promise<void> {
    if (this.loaded) {
      return;
    }
    this.conversations = await this.repo.listConversations();
    if (this.conversations.length === 0) {
      const conv = this.buildConversation();
      this.conversations = [conv];
      await this.persist();
    }
    this.currentId = this.conversations[0].id;
    this.loaded = true;
    Logger.info(Constants.TAG_SERVICE, 'conversations loaded, count=' + this.conversations.length.toString());
  }

  private buildConversation(): Conversation {
    const conv: Conversation = {
      id: DateUtil.genId('conv'),
      title: '新对话',
      createTime: DateUtil.now(),
      updateTime: DateUtil.now(),
      messages: []
    };
    return conv;
  }

  private async persist(): Promise<void> {
    await this.repo.saveConversations(this.conversations);
  }

  private findCurrent(): Conversation | null {
    for (let i = 0; i < this.conversations.length; i++) {
      if (this.conversations[i].id === this.currentId) {
        return this.conversations[i];
      }
    }
    return null;
  }

  private autoTitle(text: string): string {
    const t: string = text.trim();
    if (t.length <= 12) {
      return t;
    }
    return t.substring(0, 12) + '…';
  }

  async listConversations(): Promise<Conversation[]> {
    await this.ensureLoaded();
    return this.conversations.slice();
  }

  async getCurrentId(): Promise<string> {
    await this.ensureLoaded();
    return this.currentId;
  }

  async getCurrentMessages(): Promise<ChatMessage[]> {
    await this.ensureLoaded();
    const conv = this.findCurrent();
    if (conv === null) {
      return [];
    }
    return conv.messages.slice();
  }

  async newConversation(): Promise<void> {
    await this.ensureLoaded();
    const conv = this.buildConversation();
    this.conversations = [conv, ...this.conversations];
    this.currentId = conv.id;
    await this.persist();
  }

  async switchConversation(id: string): Promise<void> {
    await this.ensureLoaded();
    const idx = this.conversations.findIndex((c: Conversation) => c.id === id);
    if (idx >= 0) {
      this.currentId = id;
    }
  }

  async deleteConversation(id: string): Promise<void> {
    await this.ensureLoaded();
    this.conversations = this.conversations.filter((c: Conversation) => c.id !== id);
    if (this.conversations.length === 0) {
      const conv = this.buildConversation();
      this.conversations = [conv];
    }
    if (this.currentId === id) {
      this.currentId = this.conversations[0].id;
    }
    await this.persist();
  }

  // ===== 结构化分析 =====
  async generateAnalysis(): Promise<HealthAdvice> {
    const messages: ChatMessage[] = [
      { role: 'system', content: AiConfig.SYSTEM_PROMPT },
      { role: 'user', content: await this.buildAnalysisPrompt() }
    ];
    if (AiConfig.isApiKeyConfigured()) {
      try {
        const content = await this.ai.chat(messages);
        Logger.info(Constants.TAG_SERVICE, 'cloud analysis ok');
        return this.buildAdvice('analysis', '今日健康分析', '基于今日运动/饮食/睡眠记录生成。', content, false, '');
      } catch (e) {
        const reason = this.errorReason(e as Object);
        Logger.warn(Constants.TAG_SERVICE, 'cloud analysis failed: ' + reason + ', fallback local');
        return this.localAnalysis(reason);
      }
    }
    return this.localAnalysis('未配置云端 AI Key');
  }

  /** 智能问答：在当前会话上下文中追问，自动持久化记忆 */
  async askQuestion(question: string): Promise<string> {
    await this.ensureLoaded();
    const current = this.findCurrent();
    if (current === null) {
      await this.newConversation();
    }
    const conv = this.findCurrent();
    if (conv === null) {
      return this.localQa(question);
    }
    const q: string = question.trim();

    const apiMessages: ChatMessage[] = [{ role: 'system', content: AiConfig.SYSTEM_PROMPT }];
    for (let i = 0; i < conv.messages.length; i++) {
      apiMessages.push(conv.messages[i]);
    }
    apiMessages.push({ role: 'user', content: q });

    let reply: string = '';
    if (AiConfig.isApiKeyConfigured()) {
      try {
        reply = await this.ai.chat(apiMessages);
        Logger.info(Constants.TAG_SERVICE, 'cloud qa ok');
      } catch (e) {
        const reason = this.errorReason(e as Object);
        Logger.warn(Constants.TAG_SERVICE, 'cloud qa failed: ' + reason + ', fallback local');
        reply = this.localQa(q);
      }
    } else {
      reply = this.localQa(q);
    }

    conv.messages = [...conv.messages, { role: 'user', content: q }, { role: 'assistant', content: reply }];
    conv.updateTime = DateUtil.now();
    if (conv.title === '新对话') {
      conv.title = this.autoTitle(q);
    }
    await this.persist();
    return reply;
  }

  /** 连接测试：未配置 Key 直接报错，否则发一条最小请求验证连通性 */
  async testConnection(): Promise<string> {
    if (!AiConfig.isApiKeyConfigured()) {
      throw new AiServiceError(-1, '未配置 API Key，请在 common/Config.ets 填写后重新运行');
    }
    return this.ai.chat([{ role: 'user', content: '你好，请回复「连接成功」' }]);
  }

  /** 食物识别（云端视觉，未配置/失败时本地降级） */
  async analyzeFoodImage(imageDataUrl: string, hint: string): Promise<FoodRecognitionResult> {
    return this.ai.analyzeFoodVision(imageDataUrl, hint);
  }

  // ===== 建议历史（持久化）=====
  async saveAdvice(advice: HealthAdvice): Promise<void> {
    await this.repo.addAdvice(advice);
  }

  async getHistory(): Promise<HealthAdvice[]> {
    return this.repo.listAdvice();
  }

  async clearHistory(): Promise<void> {
    await this.repo.clearAdvice();
  }

  // ===== 内部实现 =====
  private async buildAnalysisPrompt(): Promise<string> {
    const service = HealthDataService.getInstance();
    const summary: DailySummary = await service.getDailySummary();
    const today: string = DateUtil.today();
    const exercises = await service.listExercise();
    const diets = await service.listDiet();
    const sleeps = await service.listSleep();

    const exerciseDetail: string[] = [];
    for (let i = 0; i < exercises.length; i++) {
      if (exercises[i].date === today) {
        exerciseDetail.push(exercises[i].type + ' ' + exercises[i].durationMinutes.toString() +
          '分钟/消耗' + exercises[i].calories.toString() + '千卡');
      }
    }
    const dietDetail: string[] = [];
    for (let i = 0; i < diets.length; i++) {
      if (diets[i].date === today) {
        dietDetail.push(diets[i].mealType + ' ' + diets[i].foodName + ' ' + diets[i].calories.toString() + '千卡');
      }
    }
    const sleepDetail: string[] = [];
    for (let i = 0; i < sleeps.length; i++) {
      if (sleeps[i].date === today) {
        sleepDetail.push(sleeps[i].quality + ' ' + sleeps[i].sleepHours.toString() + '小时');
      }
    }

    let prompt: string = '以下是我今天的结构化健康记录：\n';
    prompt += '运动：总计 ' + summary.exerciseMinutes.toString() + ' 分钟，消耗 ' +
      summary.exerciseCalories.toString() + ' 千卡';
    if (exerciseDetail.length > 0) {
      prompt += '（明细：' + exerciseDetail.join('；') + '）';
    }
    prompt += '\n饮食：总计 ' + summary.dietCalories.toString() + ' 千卡';
    if (dietDetail.length > 0) {
      prompt += '（明细：' + dietDetail.join('；') + '）';
    }
    prompt += '\n睡眠：总计 ' + summary.sleepHours.toString() + ' 小时';
    if (sleepDetail.length > 0) {
      prompt += '（明细：' + sleepDetail.join('；') + '）';
    }
    prompt += '\n请基于以上数据，生成一段简洁的健康摘要与非医疗性质的改进建议。';
    return prompt;
  }

  private async localAnalysis(reason: string): Promise<HealthAdvice> {
    await delay(400);
    const summary: DailySummary = await HealthDataService.getInstance().getDailySummary();
    const summaryText: string =
      '今日运动 ' + summary.exerciseMinutes.toString() + ' 分钟（消耗约 ' +
      summary.exerciseCalories.toString() + ' 千卡），饮食摄入约 ' +
      summary.dietCalories.toString() + ' 千卡，睡眠 ' +
      summary.sleepHours.toString() + ' 小时。';

    let suggestion: string = '';
    if (summary.exerciseMinutes < Constants.TARGET_EXERCISE_MIN) {
      suggestion += '运动量偏少，建议每天进行至少 30 分钟中低强度活动（如快走、慢跑）。';
    } else {
      suggestion += '今日运动量达标，继续保持规律运动。';
    }
    if (summary.dietCalories < Constants.LOW_CALORIES) {
      suggestion += ' 今日摄入热量偏低，注意均衡饮食，避免过度节食。';
    } else if (summary.dietCalories > Constants.HIGH_CALORIES) {
      suggestion += ' 今日摄入热量偏高，建议减少高糖高油食物，增加蔬果与优质蛋白。';
    } else {
      suggestion += ' 饮食热量总体合理，注意营养均衡。';
    }
    if (summary.sleepHours < Constants.TARGET_SLEEP_MIN) {
      suggestion += ' 睡眠不足，建议保证 7-9 小时规律睡眠，睡前减少使用电子设备。';
    } else {
      suggestion += ' 睡眠时长良好，保持规律作息。';
    }

    return this.buildAdvice('analysis', '今日健康分析', summaryText, suggestion, true, reason);
  }

  private localQa(question: string): string {
    const q: string = question.trim();
    if (q === '') {
      return '请先输入你的问题，例如「怎样改善睡眠？」。';
    } else if (q.indexOf('运动') >= 0) {
      return '建议每周进行 150 分钟中等强度运动，学生可利用课间散步或每周 3-4 次 30 分钟锻炼。';
    } else if (q.indexOf('睡眠') >= 0 || q.indexOf('失眠') >= 0) {
      return '建议固定作息时间、睡前 1 小时远离手机，卧室保持安静昏暗，逐步养成规律睡眠习惯。';
    } else if (q.indexOf('饮食') >= 0 || q.indexOf('吃') >= 0) {
      return '建议三餐规律、粗细搭配，减少含糖饮料，增加蔬菜、水果和优质蛋白摄入。';
    } else {
      return '这个问题涉及因素较多。建议先记录运动、饮食与睡眠数据，我会基于数据给出更具体的建议。';
    }
  }

  private buildAdvice(sourceType: string, title: string, summaryText: string,
    suggestionText: string, degraded: boolean, reason: string): HealthAdvice {
    const advice: HealthAdvice = {
      id: DateUtil.genId('advice'),
      createTime: DateUtil.now(),
      sourceType: sourceType,
      title: title,
      summary: summaryText,
      suggestion: suggestionText,
      disclaimer: this.buildDisclaimer(reason),
      degraded: degraded
    };
    return advice;
  }

  private buildDisclaimer(reason: string): string {
    let text: string = '以上内容仅为健康生活方式建议，不构成医疗诊断或治疗建议。如有不适请及时就医。';
    if (reason !== '') {
      text = '【降级提示】' + reason + '，以下为本地规则建议。' + text;
    }
    return text;
  }

  private errorReason(e: Object): string {
    const err = e as AiServiceError;
    if (err.message !== undefined && err.message !== '') {
      return err.message;
    }
    return '云端 AI 调用失败';
  }
}
