import { http } from '@kit.NetworkKit';
import { ChatMessage, ChatCompletionResponse, ChatRequestBody, AiServiceError, VisionContentPart, VisionRequestBody, VisionFoodJson } from '../model/AiModels';
import { FoodRecognitionResult } from '../model/HealthModels';
import { AiConfig, VisionConfig } from '../common/Config';
import { Logger } from '../common/Logger';
import { Constants } from '../common/Constants';

/**
 * 云端 AI 服务（service 层，真实 HTTP 接入）。
 * 使用 @kit.NetworkKit 的 http 模块发起 HTTPS POST，兼容 OpenAI chat/completions 协议。
 */
export class HealthAiService {
  private static instance: HealthAiService | null = null;

  static getInstance(): HealthAiService {
    if (HealthAiService.instance === null) {
      HealthAiService.instance = new HealthAiService();
    }
    return HealthAiService.instance;
  }

  private constructor() {
  }

  /**
   * 对话补全（OpenAI 兼容）。
   * @param messages 完整消息数组（含 system / user / assistant 历史，用于上下文追问）
   */
  async chat(messages: ChatMessage[]): Promise<string> {
    const request = http.createHttp();
    let httpError: boolean = false;
    let response: http.HttpResponse | null = null;

    try {
      const bodyObj: ChatRequestBody = {
        model: AiConfig.MODEL,
        messages: messages,
        stream: false
      };
      const body: string = JSON.stringify(bodyObj);
      const headers: Record<string, string> = {};
      headers['Content-Type'] = 'application/json';
      headers['Authorization'] = 'Bearer ' + AiConfig.API_KEY;

      const url: string = AiConfig.BASE_URL + AiConfig.CHAT_PATH;
      Logger.info(Constants.TAG_SERVICE, 'ai chat request start, model=' + AiConfig.MODEL);

      response = await request.request(url, {
        method: http.RequestMethod.POST,
        header: headers,
        extraData: body,
        expectDataType: http.HttpDataType.STRING,
        connectTimeout: AiConfig.CONNECT_TIMEOUT,
        readTimeout: AiConfig.READ_TIMEOUT
      });
    } catch (e) {
      httpError = true;
      Logger.error(Constants.TAG_SERVICE, 'ai chat network/timeout error');
    } finally {
      request.destroy();
      Logger.info(Constants.TAG_SERVICE, 'ai chat request destroyed');
    }

    if (httpError) {
      throw new AiServiceError(-1, '网络请求失败或超时，请检查网络后重试');
    }
    if (response === null) {
      throw new AiServiceError(-1, '网络请求失败或超时，请检查网络后重试');
    }

    const statusCode: number = response.responseCode as number;
    Logger.info(Constants.TAG_SERVICE, 'ai chat response status=' + statusCode.toString());
    if (statusCode !== 200) {
      throw new AiServiceError(statusCode, this.friendlyHttpError(statusCode));
    }

    const raw: string = response.result as string;
    return this.parseContent(raw);
  }

  /** 解析 choices[0].message.content */
  private parseContent(raw: string): string {
    let content: string = '';
    try {
      const data = JSON.parse(raw) as ChatCompletionResponse;
      const choices = data.choices;
      if (choices !== undefined && choices !== null && choices.length > 0) {
        const message = choices[0].message;
        if (message !== undefined && message !== null) {
          content = message.content;
        }
      }
    } catch (e) {
      Logger.error(Constants.TAG_SERVICE, 'ai response parse error');
      throw new AiServiceError(-2, 'AI 返回内容解析失败，请稍后重试');
    }
    if (content.trim() === '') {
      throw new AiServiceError(-2, 'AI 未返回有效内容，请稍后重试');
    }
    return content;
  }

  /** 将 HTTP 状态码转为友好提示 */
  private friendlyHttpError(code: number): string {
    if (code === 401) {
      return '鉴权失败（401）：API Key 无效或已过期';
    }
    if (code === 402) {
      return '账户余额不足（402）：请为 AI 账户充值后重试';
    }
    if (code === 400) {
      return '请求参数错误（400）：请检查请求体与模型名称';
    }
    if (code === 404) {
      return '接口不存在（404）：请检查 baseUrl 与接口路径';
    }
    if (code === 429) {
      return '请求过于频繁（429）：请稍后重试';
    }
    if (code >= 500) {
      return 'AI 服务端异常（' + code.toString() + '）：请稍后重试';
    }
    return 'AI 请求失败（' + code.toString() + '）：请稍后重试';
  }

  /**
   * 食物视觉识别：优先走云端视觉模型，未配置/失败时降级到本地启发式。
   * 降级时把具体原因写进 summary，便于在界面直接看到失败原因。
   * @param imageDataUrl 图片 base64 data URL
   * @param hint 本地降级提示词（如 apple/rice/milk）
   */
  async analyzeFoodVision(imageDataUrl: string, hint: string): Promise<FoodRecognitionResult> {
    if (VisionConfig.isConfigured()) {
      try {
        const reply = await this.chatVision(imageDataUrl);
        const parsed = this.parseFoodJson(reply);
        if (parsed !== null) {
          Logger.info(Constants.TAG_SERVICE, 'vision recognized: ' + parsed.foodName);
          return this.buildVisionResult(parsed, false);
        }
        Logger.warn(Constants.TAG_SERVICE, 'vision json parse failed, fallback local');
        return this.localFoodRecognition(hint, '云端未返回有效 JSON');
      } catch (e) {
        const reason = this.visionErrorReason(e as Object);
        Logger.warn(Constants.TAG_SERVICE, 'vision request failed: ' + reason);
        return this.localFoodRecognition(hint, reason);
      }
    }
    return this.localFoodRecognition(hint, '未配置视觉 Key');
  }

  private visionErrorReason(e: Object): string {
    const err = e as AiServiceError;
    if (err.message !== undefined && err.message !== '') {
      return err.message;
    }
    return '云端视觉调用失败';
  }

  /** 多模态视觉请求（OpenAI 兼容，content 为数组） */
  private async chatVision(imageDataUrl: string): Promise<string> {
    const request = http.createHttp();
    let httpError: boolean = false;
    let response: http.HttpResponse | null = null;
    try {
      const contentParts: VisionContentPart[] = [
        { type: 'text', text: VisionConfig.VISION_PROMPT },
        { type: 'image_url', image_url: { url: imageDataUrl } }
      ];
      const bodyObj: VisionRequestBody = {
        model: VisionConfig.MODEL,
        messages: [{ role: 'user', content: contentParts }],
        stream: false
      };
      const body: string = JSON.stringify(bodyObj);
      const headers: Record<string, string> = {};
      headers['Content-Type'] = 'application/json';
      headers['Authorization'] = 'Bearer ' + VisionConfig.API_KEY;
      const url: string = VisionConfig.BASE_URL + VisionConfig.CHAT_PATH;
      Logger.info(Constants.TAG_SERVICE, 'vision request start, model=' + VisionConfig.MODEL);
      response = await request.request(url, {
        method: http.RequestMethod.POST,
        header: headers,
        extraData: body,
        expectDataType: http.HttpDataType.STRING,
        connectTimeout: VisionConfig.CONNECT_TIMEOUT,
        readTimeout: VisionConfig.READ_TIMEOUT
      });
    } catch (e) {
      httpError = true;
      Logger.error(Constants.TAG_SERVICE, 'vision network/timeout error');
    } finally {
      request.destroy();
      Logger.info(Constants.TAG_SERVICE, 'vision request destroyed');
    }
    if (httpError) {
      throw new AiServiceError(-1, '视觉请求失败或超时，请检查网络后重试');
    }
    if (response === null) {
      throw new AiServiceError(-1, '视觉请求失败或超时，请检查网络后重试');
    }
    const statusCode: number = response.responseCode as number;
    Logger.info(Constants.TAG_SERVICE, 'vision response status=' + statusCode.toString());
    if (statusCode !== 200) {
      throw new AiServiceError(statusCode, this.friendlyHttpError(statusCode));
    }
    const raw: string = response.result as string;
    return this.parseContent(raw);
  }

  /** 从模型回复中提取并解析 JSON */
  private parseFoodJson(reply: string): VisionFoodJson | null {
    let text: string = reply.trim();
    const start: number = text.indexOf('{');
    const end: number = text.lastIndexOf('}');
    if (start >= 0 && end > start) {
      text = text.substring(start, end + 1);
    }
    try {
      const data = JSON.parse(text) as VisionFoodJson;
      if (data === null || data === undefined || data.foodName === undefined || data.foodName === '') {
        return null;
      }
      return data;
    } catch (e) {
      return null;
    }
  }

  private buildVisionResult(json: VisionFoodJson, degraded: boolean): FoodRecognitionResult {
    let nutrition: string = '';
    if (json.nutrition !== undefined) {
      nutrition = json.nutrition;
    }
    let portion: string = '';
    if (json.portion !== undefined) {
      portion = json.portion;
    }
    const result: FoodRecognitionResult = {
      foodName: json.foodName,
      confidence: 0.9,
      estimatedCalories: json.caloriesPer100g,
      summary: json.summary,
      suggestion: json.suggestion,
      nutrition: nutrition,
      portion: portion,
      imageUri: '',
      degraded: degraded
    };
    return result;
  }

  private localFoodRecognition(hint: string, reason: string): FoodRecognitionResult {
    const food: string = this.guessFoodFromHint(hint);
    let calories: number = 0;
    let nutrition: string = '';
    let portion: string = '';
    let suggestion: string = '';
    if (food === '苹果') {
      calories = 52;
      nutrition = '每 100g 约含碳水化合物 14g、膳食纤维 2.4g，几乎不含脂肪与蛋白质';
      portion = '建议每天 1 个中等大小苹果（约 200g）';
      suggestion = '适合作为两餐之间的加餐；尽量带皮食用以保留膳食纤维；减脂期可代替高糖零食；胃酸过多者建议饭后少量食用';
    } else if (food === '米饭') {
      calories = 116;
      nutrition = '每 100g 约含碳水化合物 26g、蛋白质 2.6g，脂肪极低';
      portion = '建议每餐 1 拳头大小熟米饭（约 100~150g）';
      suggestion = '建议搭配足量蔬菜和优质蛋白一起吃；可掺入糙米或杂粮提升饱腹感；减脂期适当控制总量；避免汤泡饭以免摄入过多';
    } else if (food === '牛奶') {
      calories = 54;
      nutrition = '每 100g 约含蛋白质 3g、脂肪 3g、钙约 100mg';
      portion = '建议每天 250~300ml（约 1 杯）';
      suggestion = '适合早餐或睡前 1 小时饮用；乳糖不耐受可选无乳糖奶；增肌期可作为优质蛋白来源；避免空腹大量冷饮';
    } else {
      calories = 150;
      nutrition = '营养构成未知，建议以实际包装标签为准';
      portion = '建议先少量尝试，确认后再估算份量';
      suggestion = '建议手动录入以更准确估算热量；优先选择少油少糖的烹饪方式；注意控制总量；搭配蔬菜食用更均衡';
    }

    const result: FoodRecognitionResult = {
      foodName: food,
      confidence: food === '未知食物' ? 0.4 : 0.92,
      estimatedCalories: calories,
      summary: '【降级】' + reason + '。识别结果：' + food + '（每 100g 约 ' + calories.toString() + ' 千卡）',
      suggestion: suggestion,
      nutrition: nutrition,
      portion: portion,
      imageUri: '',
      degraded: true
    };
    return result;
  }

  private guessFoodFromHint(hint: string): string {
    const lower: string = hint.toLowerCase();
    if (lower.indexOf('apple') >= 0 || lower.indexOf('苹果') >= 0) {
      return '苹果';
    }
    if (lower.indexOf('rice') >= 0 || lower.indexOf('米饭') >= 0) {
      return '米饭';
    }
    if (lower.indexOf('milk') >= 0 || lower.indexOf('牛奶') >= 0) {
      return '牛奶';
    }
    return '未知食物';
  }
}
