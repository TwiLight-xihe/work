import { ExerciseRecord, DietRecord, SleepRecord, DailySummary } from '../model/HealthModels';
import { HealthRepository } from './HealthRepository';
import { DateUtil } from '../common/DateUtil';

/**
 * 健康数据服务（service 层，门面）。
 * 对页面屏蔽持久化细节，内部委托 HealthRepository；方法签名与第一阶段保持一致，
 * 因此页面层几乎无需改动即可获得「持久化」能力。
 */
export class HealthDataService {
  private static instance: HealthDataService | null = null;
  private repo: HealthRepository = HealthRepository.getInstance();

  static getInstance(): HealthDataService {
    if (HealthDataService.instance === null) {
      HealthDataService.instance = new HealthDataService();
    }
    return HealthDataService.instance;
  }

  private constructor() {
  }

  // ===== 运动记录 CRUD =====
  async listExercise(): Promise<ExerciseRecord[]> {
    return this.repo.listExercise();
  }

  async addExercise(record: ExerciseRecord): Promise<void> {
    await this.repo.addExercise(record);
  }

  async updateExercise(record: ExerciseRecord): Promise<void> {
    await this.repo.updateExercise(record);
  }

  async deleteExercise(id: string): Promise<void> {
    await this.repo.deleteExercise(id);
  }

  // ===== 饮食记录 CRUD =====
  async listDiet(): Promise<DietRecord[]> {
    return this.repo.listDiet();
  }

  async addDiet(record: DietRecord): Promise<void> {
    await this.repo.addDiet(record);
  }

  async updateDiet(record: DietRecord): Promise<void> {
    await this.repo.updateDiet(record);
  }

  async deleteDiet(id: string): Promise<void> {
    await this.repo.deleteDiet(id);
  }

  // ===== 睡眠记录 CRUD =====
  async listSleep(): Promise<SleepRecord[]> {
    return this.repo.listSleep();
  }

  async addSleep(record: SleepRecord): Promise<void> {
    await this.repo.addSleep(record);
  }

  async updateSleep(record: SleepRecord): Promise<void> {
    await this.repo.updateSleep(record);
  }

  async deleteSleep(id: string): Promise<void> {
    await this.repo.deleteSleep(id);
  }

  // ===== 当日汇总 =====
  async getDailySummary(): Promise<DailySummary> {
    const exerciseList = await this.repo.listExercise();
    const dietList = await this.repo.listDiet();
    const sleepList = await this.repo.listSleep();
    const today: string = DateUtil.today();

    let exerciseMinutes: number = 0;
    let exerciseCalories: number = 0;
    let dietCalories: number = 0;
    let sleepHours: number = 0;
    let exerciseCount: number = 0;
    let dietCount: number = 0;
    let sleepCount: number = 0;

    for (let i = 0; i < exerciseList.length; i++) {
      if (exerciseList[i].date === today) {
        exerciseMinutes += exerciseList[i].durationMinutes;
        exerciseCalories += exerciseList[i].calories;
        exerciseCount++;
      }
    }
    for (let i = 0; i < dietList.length; i++) {
      if (dietList[i].date === today) {
        dietCalories += dietList[i].calories;
        dietCount++;
      }
    }
    for (let i = 0; i < sleepList.length; i++) {
      if (sleepList[i].date === today) {
        sleepHours += sleepList[i].sleepHours;
        sleepCount++;
      }
    }

    const summary: DailySummary = {
      exerciseMinutes: exerciseMinutes,
      exerciseCalories: exerciseCalories,
      dietCalories: dietCalories,
      sleepHours: sleepHours,
      exerciseCount: exerciseCount,
      dietCount: dietCount,
      sleepCount: sleepCount
    };
    return summary;
  }

  /** 空汇总（用于错误兜底） */
  emptySummary(): DailySummary {
    const summary: DailySummary = {
      exerciseMinutes: 0,
      exerciseCalories: 0,
      dietCalories: 0,
      sleepHours: 0,
      exerciseCount: 0,
      dietCount: 0,
      sleepCount: 0
    };
    return summary;
  }
}
